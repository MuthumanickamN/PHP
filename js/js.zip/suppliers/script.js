/*
* ------------------------------------------------------------------------------
* Suppliers js file 
* Includes scripts for Suppliers
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/

/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');
	getOrganization();
	getStates();
});

/*
* newMember click event handler
*/
$(document).on('click','#addSupplier',function() {
	var name      = $('#name').val();	
	var email     = $('#email').val();
	var pincode   = $('#pincode').val();
	var address_1 = $('#address_line_one').val();
	var address_2 = $('#address_line_two').val();
	var city      = $('#city').val();
	var state     = $('#state').val();
	var mobile    = $('#mobile').val();
	var active    = $('#active').val();
	var formData  = $('#newSupplierForm').serialize();
	var message   = '';
	var flag      = 1 ;

	if ( name == "" ){
		message = "Please enter Name";
		flag = 0;
		$('#name').focus();
		$('.message').addClass('error').html(message);
	}

	if ( org_id == "-1" ){
		message = "Please select Organization";
		flag = 0;
		$('#org_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}

	if ( mobile == "" ){
		message = "Please enter mobile";
		flag = 0;
		$('#mobile').focus();
		$('.message').addClass('error').html(message);
	}

	if ( ValidatePhone(mobile) == false ){
		message = "Please enter valid Mobile";
		flag = 0;
		$('#mobile').focus();
		$('.message').html(message);
	}

	if( email == "" ){
		message = "Please enter email";
		flag = 0;
		$('#email').focus();
		$('.message').addClass('error').html(message);
	}

	if ( ValidateEmail(email) ==  false ){
		message = "Please enter valid email";
		flag = 0;
		$('#email').focus();
		$('.message').html(message);
	}

	if ( address_1 == "" ){
		message = "Please enter Address";
		flag = 0;
		$('#address_line_one').focus();
		$('.message').addClass('error').html(message);
	}

	if ( city == "" ){
		message = "Please enter City";
		flag = 0;
		$('#city').focus();
		$('.message').addClass('error').html(message);
	}

	if ( state == "" ){
		message = "Please enter State";
		flag = 0;
		$('#state').focus();
		$('.message').addClass('error').html(message);
	}

	if ( pincode == "" ){
		message = "Please enter pincode";
		flag = 0;
		$('#pincode').focus();
		$('.message').addClass('error').html(message);
	}

	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postSupplier.php',
			data : formData,
			method : 'POST',
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});

/*
* delete member click event
*/
$(document).on('click','.deleteSupplier',function() {
	var id = $(this).attr('data-id');
	console.log(id);
	$.ajax({
		url  : serverUrl+'deleteSupplier.php',
		method : 'GET',
		data   : { 'id':id },
		success: function( response ) {
			var objData = JSON.parse( response );
			if( objData.code == 200 ){				
				message = objData.data;
				var url = objData.url;
		       	window.location.replace( url+'.php');
			}

			if( objData.code == 405 ){				
				message = objData.data;
			    $('.message').addClass('error').html(message);
			}
			
		}
	});
});


/*
* editSupplier click event handler
*/
$(document).on('click','#editSupplier',function() {
	var name      = $('#name').val();	
	var email     = $('#email').val();
	var pincode   = $('#pincode').val();
	var address_1 = $('#address_line_one').val();
	var address_2 = $('#address_line_two').val();
	var org_id    = $('#s_org_id').val();
	var city      = $('#s_city').val();
	var state     = $('#s_state').val();
	var mobile    = $('#mobile').val();
	var active    = $('#active').val();
	var formData  = $('#editSupplierForm').serialize();
	var message   = '';
	var flag      = 1 ;

	if ( name == "" ){
		message = "Please enter Name";
		flag = 0;
		$('#name').focus();
		$('.message').addClass('error').html(message);
	}

	if ( org_id == "-1" ){
		message = "Please select Organization";
		flag = 0;
		$('#s_org_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}

	if ( mobile == "" ){
		message = "Please enter mobile";
		flag = 0;
		$('#mobile').focus();
		$('.message').addClass('error').html(message);
	}

	if ( ValidatePhone(mobile) == false ){
		message = "Please enter valid Mobile";
		flag = 0;
		$('#mobile').focus();
		$('.message').html(message);
	}

	if( email == "" ){
		message = "Please enter email";
		flag = 0;
		$('#email').focus();
		$('.message').addClass('error').html(message);
	}

	if ( ValidateEmail(email) ==  false ){
		message = "Please enter valid email";
		flag = 0;
		$('#email').focus();
		$('.message').html(message);
	}

	if ( address_1 == "" ){
		message = "Please enter Address";
		flag = 0;
		$('#address_line_one').focus();
		$('.message').addClass('error').html(message);
	}

	if ( city == "" ){
		message = "Please enter City";
		flag = 0;
		$('#s_city').focus();
		$('.message').addClass('error').html(message);
	}

	if ( state == "" ){
		message = "Please enter State";
		flag = 0;
		$('#s_state').focus();
		$('.message').addClass('error').html(message);
	}

	if ( pincode == "" ){
		message = "Please enter pincode";
		flag = 0;
		$('#pincode').focus();
		$('.message').addClass('error').html(message);
	}

	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postSupplier.php',
			data : formData,
			method : 'POST',
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});


/*
* Organization Details
*/
function getOrganization(){
	$.ajax({
		url  : serverUrl+'getOrganization.php',		
		method : 'GET',
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			var htm = '';
			if ( objData.code == 200 ){
				htm += '<option value="-1">---Organization---</option>';
				$.each( objData.data, function( index, obj ){
					htm += '<option value="'+obj.id+'">'+ obj.name +'</option>';
				});
				$('#org_id').html(htm);
		    }
		   	if ( objData.code == 404 || objData.code == 405 ){	       	
	   			message = objData.data;
	   			$('.message').addClass('error').html(message);
	   		}	
	    },
	    error: function () {
	        if ( response.code == 401){
	       		window.location.replace('/');		       	
	        }
	        $('.message').addClass('error').html(message);
	    } 
	});
}

/*
* state Details
*/
function getStates(){
	$.ajax({
		url  : serverUrl+'getStates.php',		
		method : 'GET',
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			var htm = '';
			if ( objData.code == 200 ){
				htm += '<option value="-1">---States---</option>';
				$.each( objData.data, function( index, obj ){
					htm += '<option value="'+obj.id+'">'+ obj.name +'</option>';
				});
				$('#state').html(htm);
		    }
		   	if ( objData.code == 404 || objData.code == 405 ){	       	
	   			message = objData.data;
	   			$('.message').addClass('error').html(message);
	   		}	
	    },
	    error: function () {
	        if ( response.code == 401){
	       		window.location.replace('/');		       	
	        }
	        $('.message').addClass('error').html(message);
	    } 
	});
}


/*
* city Details
*/
$(document).on( 'change', '#state', function(){
	var state = $(this).val();
	$.ajax({
		url  : serverUrl+'getCitites.php',		
		method : 'POST',
		data : { 'state' : state },
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			var htm = '';
			if ( objData.code == 200 ){
				htm += '<option value="-1">---Cities---</option>';
				$.each( objData.data, function( index, obj ){
					htm += '<option value="'+obj.id+'">'+ obj.name +'</option>';
				});
				$('#city').html(htm);
		    }
		   	if ( objData.code == 404 || objData.code == 405 ){	       	
	   			message = objData.data;
	   			$('.message').addClass('error').html(message);
	   		}	
	    },
	    error: function () {
	        if ( response.code == 401){
	       		window.location.replace('/');		       	
	        }
	        $('.message').addClass('error').html(message);
	    } 
	});
});