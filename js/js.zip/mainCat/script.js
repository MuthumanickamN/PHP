/*
* ------------------------------------------------------------------------------
* Product Main Category js file 
* Includes scripts for Product Main Category
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/

/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');
});

/*
* newMember click event handler
*/
$(document).on('click','#newMainCat',function() {
	var name  = $('#name').val();	
	var active    = $('#active').val();
	var formData  =  new FormData($('#newMainCatForm')[0]);
	var message   = '';
	var flag      = 1 ;

	if ( name == "" ){
		message = "Please enter Name";
		flag = 0;
		$('#name').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}


	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postMainCat.php',
			data : formData,
			method : 'POST',
			processData: false,
    		contentType: false,
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});

/*
* delete member click event
*/
$(document).on('click','.deleteMainCat',function() {
	var id = $(this).attr('id');
	console.log(id);
	$.ajax({
		url  : serverUrl+'deleteMainCat.php',
		method : 'GET',
		data   : { 'id':id },
		success: function( response ) {
			var objData = JSON.parse( response );
			if( objData.code == 200 ){				
				message = objData.data;
				var url = objData.url;
		       	window.location.replace( url+'.php');
			}

			if( objData.code == 405 ){				
				message = objData.data;
			    $('.message').addClass('error').html(message);
			}
			
		}
	});
});

/*
* editSubCatBtn click event handler
*/
$(document).on('click','#editMainCatBtn',function() {	
	var name      = $('#display_name').val();		
	var active    = $('#active').val();
	var formData  = $('#editMainCatForm').serialize();
	var message   = '';
	var flag      = 1 ;

	if ( name == "" ){
		message = "Please enter Name";
		flag = 0;
		$('#name').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}


	if ( flag == 1 ){
		console.log(formData);
		$.ajax({
			url  : serverUrl+'postMainCat.php',
			data : formData,
			method : 'POST',
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});

/*
* opens edit modal on click event handler
*/
$(document).on('click','.showMainCat',function() {
	$('#editMainCatModal').modal('show');
	var active = $(this).attr('data-active');
	var maincat = $(this).attr('data-name');
	var id = $(this).attr('id');	
	$('#display_name').val(maincat);
	$('#status').val(active);	
	$('#main_cat_id').val(id);	
	$('#mcTitle').html( 'Details of '+ maincat);	
});
