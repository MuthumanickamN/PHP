
/*
* ------------------------------------------------------------------------------
* Script js file 
* Includes scripts for order item management
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/


$(document).ready(function()  {
  $('.ship_details').hide();
  $.ajaxSetup({
    headers: { 'access_token' : $('meta[name="access_token"]').attr('content') }
  });
});


/*
* delete member click event
*/
$(document).on('click','.deleteOrder',function() {  
    var id = $(this).attr('data-id');
    console.log(id);
    $.ajax({
        url  : serverUrl+'deleteOrder.php',
        method : 'POST',
        data   : { 'id':id, 'type':'code' },
        success: function( response ) {
            console.log( response);
            var objData = JSON.parse( response );
            if( objData.code == 200 ){              
                message = objData.data;
                var url = objData.url;
                window.location.replace( url+'.php');
            }

            if( objData.code == 405 ){              
                message = objData.data;
                $('.message').addClass('error').html(message);
            }
            
        }
    });
});

/*
 * show post press
*/

$(document).on('click', '.showOrder', function(){
    var id =  $(this).attr('id');
    window.location.replace('editOrder.php?id=' + id ); 
});

/*
* opens edit modal on click event handler
*/
$(document).on('click','.convertToInvoice',function() {
    $('#orderInfo').modal('show');
    var id       = $(this).attr('id');
    var user     = $('#user_id').val();
    var org      = $('#org_id').val();
    $('#show_order_id').val(id);    
    $('#show_order_id_title').html( 'Details of '+ id );
    loadOrderData( id, user, org );
});

/*
* opens edit modal on click event handler
*/
$(document).on('click','.changeStatus',function() {
    $('#changeStatusModel').modal('show');
    var status   = $(this).attr('data-status');   
    var order    = $(this).attr('id');           
    var cust     = $(this).attr('data-customer');                   
    var id       = $(this).attr('id');    
    var user     = $('#user_id').val();
    var org      = $('#org_id').val();
    $('#order_no').val( order );
    $('#cust_id').val( cust );
    $.ajax({
        url  : serverUrl+'getStatus.php',           
        method : 'POST',
        data: { 'user_id' : user, 'org_id' : org },
        success: function( response ) {
            console.log(response);
            var objData = JSON.parse( response );
            var htm = '';
            htm += '<option value="-1">---Status---</option>';
            if ( objData.code == 200  ){
                $.each( objData.data, function( index, obj ){
                    if( obj.id == status ){
                        htm += '<option value="'+ obj.id +'" selected = "selected" >'+ obj.status +'</option>';
                    }else{
                        htm += '<option value="'+ obj.id +'">'+ obj.status +'</option>';
                    }
                });
                $('#status').html(htm);
            }else if ( objData.code == 405 ){
                message = objData.data;
                alert(message);
            }               
        },
        error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
    });
    $('#order_id').val(id); 
    $('#order_id_title').html( 'Details of '+ id ); 
});

/* Loads order data on call */
function loadOrderData( id, user, org ){    
    $.ajax({
        url  : serverUrl+'getOrderDetails.php',
        method : 'POST',
        data: { 'order_id' : id, 'userid' : user, 'org_id' : org },
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );
            var htm = '';                       
            var custName = '';
            if ( objData.code == 200 ) {
                htm += '<table class="table table-striped table-bordered table-hover"></tr>';
                htm += '<tr><td><label clas="control-label">Date</label></td>';
                htm += '<td><input type="date" class="form-control" id="invoice_date" name ="invoice_date" /></td>';
                htm += '<td><label clas="control-label">Type</label></td>';
                htm += '<td><select class="form-control" id="invoice_type" name ="invoice_type">';
                htm += '<option value="-1">---Invoice type---</option>';
                htm += '<option value="GST">GST</option>';
                htm += '<option value="NON-GST">NON-GST</option>';
                htm += '</select></td>';
                htm += '</tr>';
                htm += '<tr><td><label clas="control-label">#Invoice</label></td>';
                htm += '<td><input type="text" class="form-control" id="invoice_no" name ="invoice_no" readonly /></td>';
                htm += '<td><label clas="control-label">#Order</label></td>';
                htm += '<td><input type="text" class="form-control" id="order_no" name ="order_no" value="'+ id +'" readonly /></td>';
                htm += '</tr>';
                htm += '</table>';
                htm += '<table class="table table-striped table-bordered table-hover"></tr>';
                htm += '<th>S.No</th>';
                htm += '<th>Item</th>';
                htm += '<th>Price</th>';
                htm += '<th>Qty</th>';
                htm += '<th>Gst</th>';
                htm += '<th>Total</th>';
                htm += '</tr>';

                $.each( objData.data, function( index, obj ){
                    $.each( obj.order_details, function( inx, order ){
                        var sno = inx+1;
                        custName = order.CUSTOMER_NAME;
                        htm += '<tr>';
                        htm += '<td><input type="hidden" name="customer_id" value="'+ order.CUSTOMER_ID+'">'+ sno +'</td>';
                        htm += '<td>'+order.PRODUCT_NAME+'</td>';
                        htm += '<td>'+order.PRODUCT_PRICE+'</td>';
                        htm += '<td>'+order.QUANTITY+'</td>';
                        htm += '<td>'+order.GST_TOTAL+'</td>';
                        htm += '<td>'+order.NET_TOTAL_PRICE+'</td>';
                        htm += '</tr>';
                    });
                });                 
                htm += '</table>';
                htm += '<div class="col-md-12 custName"><div class="col-md-3 uppercase fcolor">CUSTOMER</div>';
                htm += '<div class="col-md-9 uppercase fcolor">'+ custName +'</div>';
                htm += '</div>';
                $('.orderDetails').html(htm);
                generateInvoiceCode( user, org );
                addressData( id, user, org );
            }else if ( objData.code == 405 ){
                message = objData.data;
                $('.message').addClass('error').html( message );
            }  
        },error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
    });
}

/* loads product and order data on call */
function generateInvoiceCode( user, org ){
    $.ajax({
        url  : serverUrl+'generateInvoiceCode.php',
        method : 'POST',
        data: { 'userid' : user, 'org_id' : org },
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );
            var htm = '';        
            if ( objData.code == 200 ) {
                var ino = objData.invoice_no;
                $('#invoice_no').val( ino );
            }else if( objData.code == 405 ) {
                message = objData.data;
                $('.message').addClass('error').html( message );
            }
        },error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
    });
}


/* loads product and order data on call */
function addressData( id, user, org ){
    $.ajax({
        url  : serverUrl+'getDeliveryAddresses.php',
        method : 'POST',
        data: { 'order_id' : id, 'userid' : user, 'org_id' : org },
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );
            var htm = '';        
            if ( objData.code == 200 ) {                           
                htm += '<table class="table table-striped table-bordered table-hover"></tr>';
                htm += '<th>Select</th>';                
                htm += '<th>S.No</th>';
                htm += '<th>Address</th>';                
                htm += '</tr>';
                $.each( objData.data, function( index, obj ){
                    $.each( obj.delivery_to, function( inx, address ){                        
                        var sno = inx+1;                    
                        htm += '<tr>';
                        if( address.IS_DEFAULT == 1 ){
                            htm += '<td><input type="checkbox" id="delivery_address" name="delivery_address" checked = "checked" value="'+address.ADDRESS_ID+'" /></td>';
                        }else{
                            htm += '<td><input type="checkbox" id="delivery_address" name="delivery_address" value="'+address.ADDRESS_ID+'" ></td>';
                        }
                        htm += '<td>'+ sno +'</td>';
                        htm += '<td>'+ address.BUILDING +','+ address.STREET +',';            
                        if( address.LANDMARK != "" || address.LANDMARK != null ) {
                            htm += address.LANDMARK+',<br/>';
                        }
                        htm += address.CITY+'-'+address.PIN+',';
                        htm += address.STATE+','+address.COUNTRY+'<br/>';
                        htm += '</td>';                        
                        htm += '</tr>';
                    });
                });     
                htm += '</table>';
                console.log( htm );
                $('.addressDetails').html(htm);
            }else if ( objData.code == 405 ){
                message = objData.data;
                $('.message').addClass('error').html( message );
            }  
        },error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
    });
}
    
/*
* change on order status
*/
$(document).on( 'change', '#status', function(){
    var user     = $('#user_id').val();
    var org      = $('#org_id').val();
    var order_id = $('#order_id').val();
    var status   = $(this).val();
    if( status == 4 || status == 5 ){
        $('.ship_details').show();
        productOrderData( order_id, user, org, status );
    }else if( status == 1 || status == 2 || status == 3 || status == 6 || status == 7 || status == 8   ) {
        $('.ship_details').hide();
        $('.orderProductDetails').html('');
    }else{
        $('.status-message').html('Select order status');
    }
});


/* loads product and order data on call */
function productOrderData( id, user, org, status ){
    $.ajax({
        url  : serverUrl+'getProductOrderDetails.php',
        method : 'POST',
        data: { 'order_id' : id, 'userid' : user, 'org_id' : org },
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );
            var htm = '';                       
            if ( objData.code == 200 ) {
                var custName = '';
                htm += '<table class="table table-striped table-bordered table-hover"></tr>';
                htm += '<th>S.No</th>';
                htm += '<th>PRODUCT CODE</th>';
                htm += '<th>AQ</th>';
                htm += '<th>OQ</th>';            
                htm += '<th>EDQ</th>';            
                htm += '</tr>';

                $.each( objData.data, function( index, obj ){
                    $.each( obj.order_details, function( inx, order ){
                        var sno = inx+1;
                        custName = order.CUSTOMER_NAME;
                        htm += '<tr>';
                        htm += '<td>'+ sno +'</td>';
                        htm += '<td>'+order.PRODUCT_CODE+'<input type="hidden" id="product_'+inx+'"  name="product[]" value="'+ order.PRODUCT_CODE +'" /></td>';
                        htm += '<td>'+order.AVAILABLE_STOCK+'<input type="hidden" id="stock_'+inx+'"  name="stock[]" value="'+ order.AVAILABLE_STOCK +'" /></td></td>';
                        htm += '<td>'+order.QUANTITY+'<input type="hidden" id="qty_'+inx+'"  name="qty[]" value="'+ order.QUANTITY +'" /></td></td>';       
                        if( status == 4 ) {
                            htm += '<td><input type="text" class="form-control" id="edq_'+inx+'" name="edq[]" placeholder="Estimated Delivery Qty" value="'+ order.QUANTITY +'" /></td>';
                        }if( status == 5 ) {
                            htm += '<td><input type="text" class="form-control" id="edq_'+inx+'"  name="edq[]" placeholder="Estimated Delivery Qty" value="" /></td>';
                        }
                        htm += '</tr>';
                    });
                });     
                htm += '</table>';
                htm += '<div class="col-md-12 custName">';
                htm += '<div class="col-md-3 uppercase fcolor">CUSTOMER</div>';
                htm += '<div class="col-md-9 uppercase fcolor">'+ custName +'</div>';
                htm += '</div>';
                $('.orderProductDetails').html(htm);
            }else if ( objData.code == 405 ){
                message = objData.data;
                $('.message').addClass('error').html( message );
            }  
        },error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
    });
}

/*
* convert order to invoice event handler
*/
$(document).on('click','#convertToInvoiceBtn',function() {            
    var fData = $('#orderInfoForm').serialize();
    $.ajax({
        url  : serverUrl+'convertOrderToInvoice.php',
        method : 'POST',
        data: fData,
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );
            var htm = '';                       
            if ( objData.code == 200 ) {
                message = objData.data;
                message = message+'&nbsp; <a href="'+ objData.url +'.php">Goto Invoice</a>';
                $('.order-message').addClass('error').html( message );
            }else if ( objData.code == 405 ){
                message = objData.data;
                $('.order-message').addClass('error').html( message );
            } 
        },error: function () {
            $('.order-message').addClass('error').html('Request Failed. Cannot connect to server');
        }         
    });
});


/*
* change status btn event handler
*/
$(document).on('click','#changeStatusBtn',function() {     
    var fData = $('#changeStatusForm').serialize();
    $.ajax({
        url  : serverUrl+'changeStatus.php',
        method : 'POST',
        data: fData,
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );
            var htm = '';                       
            if ( objData.code == 200 ) {
                message = objData.data;
                message = message;
                $('.status-message').addClass('error').html( message );
            }else if ( objData.code == 405 ){
                message = objData.data;
                $('.status-message').addClass('error').html( message );
            } 
        },error: function () {
            $('.status-message').addClass('error').html('Request Failed. Cannot connect to server');
        }         
    });
});
