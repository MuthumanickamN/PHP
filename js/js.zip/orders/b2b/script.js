
/*
* ------------------------------------------------------------------------------
* Script js file 
* Includes scripts for order item management
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/

var gst = 0;
var net = 0;
var gross = 0;

$(document).ready(function()  {
  $.ajaxSetup({
    headers: { 'access_token' : $('meta[name="access_token"]').attr('content') }
  });
  generateOrderId();  
  loadCustomers();
});

$(document).ready(function() {
    $('#product').typeahead({
        source: function(query, result) {
            $('.message').html('');
            $.ajax({
                url: "getProducts.php",
                data: 'query=' + query,
                dataType: "json",
                type: "POST",
                success: function(data) {
                    console.log( data )
                    result($.map(data, function(item) {
                        return item;
                    }));
                }
            });
        }
    });
});


/* Getting batch number for a product */
function batchNumber( org_id ){
    var product = $('#product').val()
    $.ajax({
        url  : serverUrl+'getBatchNumber.php',
        method : 'POST',
        data: { 'org_id' : org_id, 'product' : product },
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );
            var htm = '';
            if ( objData.code == 200 ){
                htm += '<option value="-1">---Batch No---</option>';
                $.each( objData.data, function( index, obj ){
                    htm += '<option value="'+obj.BATCH_NO+'">'+ obj.BATCH_NO +'</option>';
                });
                $('#batch_no').html(htm);                
            }
            if ( objData.code == 404 || objData.code == 405 ){          
                message = objData.data;
                $('.message').addClass('error').html(message);
            }
        },
        error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
    });
}

/*
* add item event 
*/
$(document).on( 'click', '#addItem', function(){
    var product  = $('#product').val();
    var quantity = $('#quantity').val();
    var batch_no = $('#batch_no').val();
    var customer = $('#customer').val();
    var flag     = 1;
    if( product == "" ){
        message = "Please enter product";
        flag = 0;
        $('#product').focus();
        $('.message').addClass('error').html(message);
    }
    if( quantity == "" ){
        message = "Please enter quantity";
        flag = 0;
        $('#quantity').focus();
        $('.message').addClass('error').html(message);
    }
    if( batch_no == "-1" ){
        message = "Please select batch number";
        flag = 0;
        $('#batch_no').focus();
        $('.message').addClass('error').html(message);
    }
    if( customer == "-1" ){
        message = "Please select Customer";
        flag = 0;
        $('#customer').focus();
        $('.message').addClass('error').html(message);
    }
    if( flag == 1 ){
        var fData = $('#productForm').serialize();        
        $.ajax({
            url  : serverUrl+'postOrderItem.php',
            method : 'POST',
            data: fData,
            success: function( response ) {
                console.log( response );
                var objData = JSON.parse( response );                                
                var product = '';
                var product_code = '';            
                var quantity = '';
                var total = 0;
                var htm = '';
                if( objData.code == 200 ) {                                   
                    $.each( objData.data, function( index, obj ){
                        product = obj.product_name;
                        product_code = obj.product_code;
                        quantity = obj.quantity;
                        total = parseFloat( obj.net_total );
                        net = net + parseFloat( obj.net_total );
                        gst = gst + parseFloat( obj.gst_total );
                        gross = gross + parseFloat( obj.gross_total );
                        htm += '<tr id="item_'+ obj.id +'">';                        
                        htm += '<td class="center uppercase"><a target = "_blank" href=editProduct.php?id='+product_code+'>'+ product_code +'</a></td>';
                        htm += '<td class="center uppercase">'+ product +'</td>';                        
                        htm += '<td class="center uppercase">'+ quantity +'</td>';
                        htm += '<td class="center uppercase">'+ total +'</td>';
                        htm += '<td class="center uppercase"><a href="javascript:void(0);" class="removeItem" id="'+obj.id+'"><i class="fa fa-close"></a></</td>';
                        htm += '</tr>';
                        $(".order_table tbody").append(htm);
                    });                     
                    $('#gst_total').val( gst );
                    $('#net_total').val( net );
                    $('#gross_total').val( gross );
                }
                if ( objData.code == 404 || objData.code == 405 ){                              
                        message = objData.data;                    
                    $('.message').addClass('error').html(message);
                } 
            },
            error: function () {
                $('.message').addClass('error').html('Request Failed. Cannot connect to server');
            } 
        });
    }
});

/*
* remove order item event
*/
$(document).on( 'click','.removeItem', function(){
    var user     = $('#user_id').val();
    var org      = $('#org_id').val();
    var item_id  = $(this).attr('id');
    $.ajax({
        url  : serverUrl+'deleteOrderItem.php',
        method : 'POST',
        data: { 'user_id' : user, 'org_id' : org, 'item_id' : item_id },
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );                                
            if( objData.code == 200 ) {                                
                $('#item_'+item_id).remove();
                alert( objData.data );                            
            }
            if ( objData.code == 404 || objData.code == 405 ){                          
                message = objData.data;                
                $('.message').addClass('error').html(message);
            } 
        },
        error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
    });
});


/*
*  loads order on page load
*/
function generateOrderId(){
    var user = $('#user_id').val();
    var org  = $('#org_id').val();    
    $.ajax({
        url  : serverUrl+'generateOrdCode.php',
        method : 'POST',
        data: { 'userid' : user, 'orgid' : org },
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );            
            console.log( objData.order_id );
            if ( objData.code == 200 ){
                $('.order_id').val( objData.order_id );
            }
            if ( objData.code == 404 || objData.code == 405 ){          
                message = objData.data;
                $('.message').addClass('error').html(message);
            }
        },
        error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
    });
}

/*
*  loads customer on page load
*/

function loadCustomers(){
    var user = $('#user_id').val();
    var org  = $('#org_id').val();
    var otype= $('#order_type').val();
    var message = '';
    $.ajax({
        url  : serverUrl+'getCustomers.php',
        method : 'POST',
        data: { 'user_id' : user, 'org_id' : org, 'order_type' : otype },
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );                    
            $('#customer').html('');
            if( objData.code == 200 ) {                
                var htm = '';
                if( otype == "B2B"){                                        
                    htm += '<option value="-1">---Customer---</option>';
                    $.each( objData.data, function( index, obj ){   
                        htm += '<option value="'+ obj.cust_id+'">'+ obj.company_name +'</option>';
                    });                    
                    $('#customer').html(htm);                    
                }
                var html = '';
                if( otype == "B2C"){                    
                    html += '<option value="-1">---Customer---</option>';
                    $.each( objData.data, function( index, obj ){                                        
                        html += '<option value="'+ obj.cust_id+'">'+ obj.company_name+'</option>';
                    });
                    $('#customer').html(html);
                }                                
            }
            if ( objData.code == 404 || objData.code == 405 ){          
                $.each( objData.data, function( index, obj ){
                    message = obj.message;
                });
                $('.message').addClass('error').html(message);
            } 
        },
        error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
    });
}

/*
* loading PO
*/
$(document).on( 'change','#customer', function(){
    var user       = $('#user_id').val();
    var org        = $('#org_id').val();
    var cust_id    = $(this).val();
    var order_type = $('#order_type').val();
    $('#customerId').val(cust_id);
    if( order_type == "B2B" ){
        $.ajax({
            url  : serverUrl+'getPo.php',
            method : 'POST',
            data: { 'user_id' : user, 'org_id' : org, 'cust_id' : cust_id },
            success: function( response ) {
                console.log( response );
                var objData = JSON.parse( response );                                
                if( objData.code == 200 ) {                
                    var html = '';
                    html += '<option value="-1">---PO---</option>';
                    $.each( objData.data, function( index, obj ){
                        html += '<option value="'+ obj.id+'">'+ obj.po_no +'- '+ obj.amount +'</option>';
                    });
                    $('#po').html(html);
                }
                if ( objData.code == 404 || objData.code == 405 ){          
                    $.each( objData.data, function( index, obj ){
                        message = obj.message;
                    });
                    $('.message').addClass('error').html(message);
                } 
            },
            error: function () {
                $('.message').addClass('error').html('Request Failed. Cannot connect to server');
            } 
        });
    }
});

/*
* save order item event 
*/
$(document).on( 'click', '#saveOrder', function(){
    var customer  = $('#customerId').val();    
    var po        = $('#po').val();
    var order_id  = $('#order_id').val();
    var order_type= $('#order_type').val();
    var org_id    = $('#org_id').val();
    var net_total = $('#net_total').val();
    var flag      = 1;
    if( customer == "" ){
        message = "Please enter Customer";
        flag = 0;
        $('#customer').focus();
        $('.message').addClass('error').html(message);
    }    
    if( flag == 1 ){        
        $.ajax({
            url  : serverUrl+'postOrder.php',
            method : 'POST',
            data: { 'customer' : customer, 'po' : po, 'order_type': order_type, 'order_id': order_id, 'org_id' : org_id, 'net_total' : net_total },
            success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );
             if( objData.code == 200 ) {                                                
                alert( objData.data );                            
                window.location.replace( objData.url + '.php' );
            }
            if ( objData.code == 404 || objData.code == 405 ){                          
                message = objData.data;                
                $('.message').addClass('error').html(message);
            } 
        },
        error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
        }); 
    }
});