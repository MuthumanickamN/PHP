	/*
	* ------------------------------------------------------------------------------
	* Invoices js file 
	* Includes scripts for Invoices
	* Author Dinesh Kumar Muthukrishnan 
	* -------------------------------------------------------------------------------
	*/

	/*
	* Clear message 
	*/
	$(document).ready(function(){
		$('.message').html('');		
		generateCode();	
		generateConCode();	
	});
var cnt = 1;    	

$(document).on('click', '.add-row', function(){
    var htm = '';
    htm += '<tr>';
    htm += '<td width="35%" style="text-align:center; height:20px;"><input type="text" placeholder="Item" name="item[]" id="item_'+cnt+'" class="form-control" data-index="'+cnt+'"/>';   
	htm += '</td>';
    htm += '<td width="8%" style="text-align:center; height:20px;"><input type="text" placeholder="HSN" name="hsn[]" id="hsn_'+cnt+'" class="form-control"  data-index="'+cnt+'"/></td>';
    htm += '<td width="8%" style="text-align:center; height:20px;"><input type="text" placeholder="Qty" name="qty[]" id="qty_'+cnt+'" class="form-control qty"  data-index="'+cnt+'"/></td>';
    htm += '<td width="10%" style="text-align:center; height:20px;"><input type="text" placeholder="Rate" name="rate[]" id="rate_'+cnt+'" class="form-control price"  data-index="'+cnt+'"/></td>';
    htm += '<td style="height:15px;" ><input type="text" placeholder="GST" data-index="'+cnt+'" name="gst[]" id="gst_'+cnt+'" class="form-control gst" /></td>';
    htm += '<td width="10%" style="text-align:center; height:20px;"><input type="text" data-index="'+cnt+'" placeholder="Total" name="total[]" id="total_'+cnt+'" class="form-control"/></td>';
    htm += '<td align="center">';
    htm += '<span class="icons"><a href="javascript:void(0);" class="add-row"><i class="fa fa-plus"></i></a></span>';
    htm += '</td>';
    htm += '<td align="center">';
    htm += '<span class="icons"><a href="javascript:void(0);" class="delete-row">&nbsp;<i class="fa fa-trash"></i></a></span>';
    htm += '</td>';
    htm += '</tr>';
    $("table tbody").append(htm);
    cnt++;
});
        
// Find and remove selected table rows
$(document).on('click', '.delete-row', function(){    
    $(this).parents("tr").remove();
    cnt = cnt-1;	
});
	        
// Find and remove selected table rows
$(document).on('click', '.delete-row', function(){
    $("table tbody").find('input[name="record"]').each(function(){
        if($(this).is(":checked")){
            $(this).parents("tr").remove();
            cnt = cnt-1;
        }	        
    });
});


$( document ).on( 'keyup', '#customer', function(){
	var val = $(this).val();
	$.ajax({
		type: "POST",
		url: "getCustomerList.php",
		data:'keyword='+val,
		beforeSend: function(){
			$("#qproduct").css("background","#FFF url(images/LoaderIcon.gif) no-repeat 200px");
		},
		success: function(data){			
			$("#suggesstion-box").show();
			$("#suggesstion-box").html(data);
			$("#name").css("background","#FFF");
		},
		error: function () {
		    $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		} 
	});
});

function selectCustomer( name, phone ) {
	$("#customer").val(name);
	$("#suggesstion-box").hide();
	$.ajax({
			url  : serverUrl+'getCustomerById.php',
			method : 'GET',
			data: { 'mobile' : phone },
			success: function( response ) {
				console.log( response );
    			var objData = JSON.parse( response );
				if( objData.code == 200 ){	
					$.each( objData.data, function ( index, obj ) {
						$('#customer_id').val( obj.id );					
					});	
				}	
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
}

	
/*
	* loads the invoice code based on selection
	*/
	function generateCode() {	
		$.ajax({
			url  : serverUrl+'generateInvoiceCode.php',
			method : 'GET',		
			success: function( response ) {
				console.log( response );
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){			
					$('#invoice_no').val( objData.data );
					$('#ino').val( objData.data );
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
			},
			error: function () {
			    $('.message').addClass('error').html('Request Failed. Cannot connect to server');
			} 
		});
	}

/*
	* loads the invoice code based on selection
	*/
	function generateConCode() {	
		$.ajax({
			url  : serverUrl+'generateConCode.php',
			method : 'GET',		
			success: function( response ) {
				console.log( response );
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){			
					$('#consignment_no').val( objData.data );
					$('#con_id').val( objData.data );
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
			},
			error: function () {
			    $('.message').addClass('error').html('Request Failed. Cannot connect to server');
			} 
		});
	}

	/*
	* onchange quantity
	*/
	$( document ).on( 'change', '.gst', function(){
		$('.message').html('');
		var gst = $(this).val();
		console.log( gst );		
		var inx = $(this).attr('data-index');		
		var price  = $( '#rate_'+inx ).val();
		console.log( price );						
		var quantity = $( '#qty_'+inx ).val();	
		console.log( inx + '------' + quantity );	
		var subtotal = parseInt(quantity)*parseFloat(price);				
		var total  = subtotal + ( subtotal * gst / 100 );
		console.log( total );
		subtotal = parseFloat(total).toFixed(2);
		$('#total_'+inx).val(total);
	});


/*
* invoice items click event handler
*/
$(document).on('click','#iDetails',function() {
	var name  = $('#name').val();
	var formData  =  new FormData($('#invoiceDetails')[0]);
	var flag = 1;

	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postTempInvoice.php',
			data : formData,
			method : 'POST',
			processData: false,
    		contentType: false,
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;		       		
					$('.message').addClass('success').html(message);
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});

/*
* consignment click event handler
*/
$(document).on('click','#cDetails',function() {
	alert('');
	var name  = $('#name').val();
	var formData  =  $('#consignmentDetails').serialize();
	var flag = 1;

	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postConsignment.php',
			data : formData,
			method : 'POST',
			success: function( response ) {
				console.log(response);				
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;		       		
					alert(message);
					window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});

/*
* delete member click event
*/
$(document).on('click','.deleteInvoice',function() {	
	var id = $(this).attr('data-id');
	console.log(id);
	$.ajax({
		url  : serverUrl+'deleteInvoice.php',
		method : 'POST',
		data   : { 'id':id, 'type' : 'invoice' },
		success: function( response ) {
			console.log( response);
			var objData = JSON.parse( response );
			if( objData.code == 200 ){				
				message = objData.data;
				var url = objData.url;
		       	window.location.replace( url+'.php');
			}

			if( objData.code == 405 ){				
				message = objData.data;
			    $('.message').addClass('error').html(message);
			}
			
		}
	});
});

/*
 * show post press
*/

$(document).on('click', '.showInvoice', function(){
	var id =  $(this).attr('id');
	window.location.replace('editInvoice.php?id=' + id );	
});
