/*
* ------------------------------------------------------------------------------
* organizations bank details js file 
* Includes scripts for organizations
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/
/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');
});

$(document).ready(function()  {
  $.ajaxSetup({
    headers: { 'access_token' : $('meta[name="access_token"]').attr('content') }
  });
});

/*
* editSubCatBtn click event handler
*/
$(document).on('click','#bDetails',function() {		
	var formData  = $('#bankDetailsForm').serialize();
	var message   = '';
	var flag      = 1 ;
	if ( flag == 1 ){
		console.log(formData);
		$.ajax({
			url  : serverUrl+'postBank.php',
			data : formData,
			method : 'POST',
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
					alert( message );
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}
});

/*
* opens edit modal on click event handler
*/
$(document).on('click','.showOrganization',function() {	
	var id = $(this).attr('id');
	window.location.replace('editOrganizaton.php?code='+id );
});
