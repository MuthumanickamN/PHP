/*
* ------------------------------------------------------------------------------
* Product sub Category js file 
* Includes scripts for Product sub Category
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/
/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');	
	$('[data-toggle="tooltip"]').tooltip(); 
	getOrganization();
	getSuppliers();	
	getTaxes();	
	getMainCat();
});

/*
* newMember click event handler
*/
$(document).on('click','#addProduct',function() {	
	var name  = $('#name').val();
	var hsn  = $('#hsn').val();
	var batch_no  = $('#batch_no').val();
	var parent_id = $('#parent_id').val();
	var available_stock  = $('#available_stock').val();
	var child_id = $('#child_id').val();	
	var tax = $('#taxes').val();	
	var active    = $('#active').val();
	var formData  =  new FormData($('#newProductForm')[0]);
	var message   = '';
	var flag      = 1 ;

	if ( name == "" ){
		message = "Please enter Name";
		flag = 0;
		$('#name').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}

	if ( parent_id == "-1" ){
		message = "Please select Main Category";
		flag = 0;
		$('#parent_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( child_id == "-1" ){
		message = "Please select Sub Category";
		flag = 0;
		$('#child_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( batch_no == "" ){
		message = "Please enter Batch";
		flag = 0;
		$('#batch_no').focus();
		$('.message').addClass('error').html(message);
	}

	if ( hsn == "" ){
		message = "Please enter HSN ";
		flag = 0;
		$('#hsbn').focus();
		$('.message').addClass('error').html(message);
	}

	if ( available_stock == "" ){
		message = "Please enter available stock";
		flag = 0;
		$('#available_stock').focus();
	}

	if ( tax == "-1" ){
		message = "Please select Tax";
		flag = 0;
		$('#taxes').focus();
		$('.message').addClass('error').html(message);
	}

	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postProduct.php',
			data : formData,
			method : 'POST',
			processData: false,
    		contentType: false,
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});

/*
* delete member click event
*/
$(document).on('click','.deleteProduct',function() {
	var id = $(this).attr('data-id');
	console.log(id);
	$.ajax({
		url  : serverUrl+'deleteProduct.php',
		method : 'GET',
		data   : { 'id':id },
		success: function( response ) {
			var objData = JSON.parse( response );
			if( objData.code == 200 ){				
				message = objData.data;
				var url = objData.url;
		       	window.location.replace( url+'.php');
			}

			if( objData.code == 405 ){				
				message = objData.data;
			    $('.message').addClass('error').html(message);
			}
			
		}
	});
});

/*
 * show post press
*/

$(document).on('click', '.showProduct', function(){
	var id =  $(this).attr('id');
	window.location.replace('editProduct.php?id=' + id );	
});

/*
 * show post press
*/

$(document).on('click', '.showProductPrice', function(){
	var id =  $(this).attr('id');
	var batch =  $(this).attr('data-batch');
	window.location.replace('productPrice.php?id=' + id +'&batch='+batch);	
});

/*
* get taxes
*/
function getTaxes(){
	$.ajax({
		url  : serverUrl+'getTaxes.php',
		method : 'GET',	
		success: function( response ) {
			console.log( response);
			var objData = JSON.parse( response );
			var htm = '';
			if ( objData.code == 200  ){
				htm += '<option value="-1">-- Taxes --</option>';
				$.each( objData.data,function( inx, obj ){
					htm += '<option value = "'+ obj.id +'">'+ obj.name +'</option>';
				});				
				$('#tax').html(htm);
			}else if ( objData.code == 405 ){
			   	message = objData.data;
			   	$('.message').addClass('error').html(message);
			} 			    
		}, error: function () {
		   $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		} 
	});
}


/*
* generateBarcode
*/
$( document ).on( 'click', '#generateBarcode', function(){
	$.ajax({
		url  : serverUrl+'generateBarcode.php',
		method : 'GET',		
		success: function( response ) {			
			console.log(response)
			var objData = JSON.parse( response );			
			$("#barcode").val( objData.data );
		},
		error: function () {
		    $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		}
	});
});


/*
* Generate Product code
*/
$( document ).on( 'click', '#generatePcode', function(){	
	var flag = 1;
	if( flag == 1 ){
		$.ajax({
			url  : serverUrl+'generateProductCode.php',
			method : 'GET',				
			success: function( response ) {
				console.log( response);
				var objData = JSON.parse( response );
				
				if ( objData.code == 200  ){
					$('#pcode').val( objData.data );
					$('.message').html('');
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
			}, error: function () {
			   $('.message').addClass('error').html('Request Failed. Cannot connect to server');
			} 
		});
	}
});


/*
* loads the main category based on selection
*/
function getMainCat(){
	$.ajax({
			url  : serverUrl+'getMainCat.php',
			method : 'GET',
			success: function( response ) {
				console.log( response);
				var objData = JSON.parse( response );
				var htm = '';
				htm += '<option value="-1">--- Main Category ---</option>';
				if ( objData.code == 200  ){
					$.each( objData.data,function( index, maincat ){
						htm += '<option value="' + maincat.id + '">'+ maincat.name + '</option>';
					});
					$('#parent_id').html(htm);
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
}


/*
* Sub category
*/
$( document ).on( 'change', '#parent_id', function(){
	var parent_id = $(this).val();
	console.log( parent_id );
	$.ajax({
			url  : serverUrl+'getSubCat.php',
			method : 'GET',
			data: { parent_id : parent_id },
			success: function( response ) {
				console.log( response);
				var objData = JSON.parse( response );
				var htm = '';
				htm += '<option value="-1">--- Sub Category ---</option>';
				if ( objData.code == 200  ){
					$.each( objData.data,function( index, subcat ){
						htm += '<option value="' + subcat.id + '">'+ subcat.name + '</option>';
					});
					$('#child_id').html(htm);
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
});

/*
* Organization Details
*/
function getOrganization(){
	$.ajax({
		url  : serverUrl+'getOrganization.php',		
		method : 'GET',
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			var htm = '';
			if ( objData.code == 200 ){
				htm += '<option value="-1">---Organization---</option>';
				$.each( objData.data, function( index, obj ){
					htm += '<option value="'+obj.id+'">'+ obj.name +'</option>';
				});
				$('#org_id').html(htm);
		    }
		   	if ( objData.code == 404 || objData.code == 405 ){	       	
	   			message = objData.data;
	   			$('.message').addClass('error').html(message);
	   		}	
	    },
	    error: function () {
	        if ( response.code == 401){
	       		window.location.replace('/');		       	
	        }
	        $('.message').addClass('error').html(message);
	    } 
	});
}

/*
* Suppliers Details
*/
function getSuppliers(){
	$.ajax({
		url  : serverUrl+'getSuppliers.php',		
		method : 'GET',
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			var htm = '';
			if ( objData.code == 200 ){
				htm += '<option value="-1">---Suppliers---</option>';
				$.each( objData.data, function( index, obj ){
					htm += '<option value="'+obj.id+'">'+ obj.name +'</option>';
				});
				$('#supplier_id').html(htm);
		    }
		   	if ( objData.code == 404 || objData.code == 405 ){	       	
	   			message = objData.data;
	   			$('.message').addClass('error').html(message);
	   		}	
	    },
	    error: function () {
	        if ( response.code == 401){
	       		window.location.replace('/');		       	
	        }
	        $('.message').addClass('error').html(message);
	    } 
	});
}