/*
* ------------------------------------------------------------------------------
* Product sub Category js file 
* Includes scripts for Product sub Category
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/

/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');
});

/*
* newMember click event handler
*/
$(document).on('click','#editProduct',function() {
	var name  = $('#name').val();
	var hsn  = $('#hsn').val();
	var batch_no  = $('#batch').val();
	var parent_id = $('#parent_id').val();
	var available_stock  = $('#available_stock').val();
	var child_id = $('#child_id').val();
	
	var tax = $('#taxes').val();	
	var active    = $('#active').val();
	var formData  =  $('#editProductForm').serialize();
	var message   = '';
	var flag      = 1 ;

	if ( name == "" ){
		message = "Please enter Name";
		flag = 0;
		$('#name').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}

	if ( parent_id == "-1" ){
		message = "Please select Main Category";
		flag = 0;
		$('#parent_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( child_id == "-1" ){
		message = "Please select Sub Category";
		flag = 0;
		$('#child_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( batch_no == "" ){
		message = "Please enter Batch";
		flag = 0;
		$('#batch_no').focus();
		$('.message').addClass('error').html(message);
	}

	if ( hsn == "" ){
		message = "Please enter HSN ";
		flag = 0;
		$('#hsn').focus();
		$('.message').addClass('error').html(message);
	}

	if ( available_stock == "" ){
		message = "Please enter available stock";
		flag = 0;
		$('#available_stock').focus();
	}

	if ( tax == "-1" ){
		message = "Please select Tax";
		flag = 0;
		$('#taxes').focus();
		$('.message').addClass('error').html(message);
	}

	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postProduct.php',
			data : formData,
			method : 'POST',
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
					alert( message );
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});

/*
* ponlc on change event
*/
$( document ).on( 'change', '#ponlc', function(){
	var ponlc = $(this).val();
	var landing_cost = $('#landing_cost').val();
	if( landing_cost == "" ){
		$('.message').addClass('error').html('Please fill landing cost first');
		$('#landing_cost').focus();
	}else{		
		var precentage = ( ponlc / 100 ) * landing_cost;
		$('#selling_cost').val( parseInt( landing_cost ) +  precentage  );
	}
});

/*
* landing_cost on change event
*/
$( document ).on( 'change', '#landing_cost', function(){
	$('.message').html('');
	var ponlc = $('#ponlc').val();
	if( ponlc == ""){
		$('.message').addClass('error').html('Please fill profit on landing cost');
		$('#ponlc').focus();
	}else{
		$('#ponlc').change().trigger();	
	}
});

/*
* attribute change event
*/
$( document ).on( 'change', '#pattribute', function(){
	var attr = $(this).val();

	if( attr == 6 ){
		$('.pattrCnt').show();
	}else{
		$('.pattrCnt').hide();
	}
});

/*
* Sub category
*/
$( document ).on( 'change', '#parent_id', function(){
	var parent_id = $(this).val();	
	$.ajax({
			url  : serverUrl+'getSubCat.php',
			method : 'GET',
			data: { parent_id : parent_id },
			success: function( response ) {
				console.log( response);
				var objData = JSON.parse( response );
				var htm = '';
				htm += '<option value="-1">--- Sub Category ---</option>';
				if ( objData.code == 200  ){
					$.each( objData.data,function( index, subcat ){
						htm += '<option value="' + subcat.id + '">'+ subcat.name + '</option>';
					});
					$('#child_id').html(htm);
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
});