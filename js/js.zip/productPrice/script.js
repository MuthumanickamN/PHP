/*
* ------------------------------------------------------------------------------
* Product price js file 
* Includes scripts for Product price
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/
/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');		
	$('[data-toggle="tooltip"]').tooltip(); 
	$.ajaxSetup({
    	headers: { 'access_token' : $('meta[name="access_token"]').attr('content') }
  	});
});

/*
* Save All
*/
$(document).on( 'click', '#updateAll', function() {
	var fdata = $('#productPriceForm').serialize();
	$.ajax({
        url  : serverUrl+'updateProductPrice.php',
        method : 'POST',
        data: fdata,
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );                                
            if( objData.code == 200 ) {     
            	message = objData.data;                                           
                $('.message').addClass('success').html(message);
            }
            if ( objData.code == 404 || objData.code == 405 ){                          
                message = objData.data;                
                $('.message').addClass('error').html(message);
            } 
        },
        error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
    });
});