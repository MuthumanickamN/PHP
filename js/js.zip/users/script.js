/*
* ------------------------------------------------------------------------------
* User Main Category js file 
* Includes scripts for User Main Category
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/

/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');
	loadOrganization();
	loadRoles();
});

/*
* newMember click event handler
*/
$(document).on('click','#addUser',function() {
	var username  = $('#username').val();	
	var password  = $('#password').val();	
	var role      = $('#role_id').val();	
	var org       = $('#org_id').val();	
	var active    = $('#active').val();
	var formData  = $('#newUserForm').serialize();
	var message   = '';
	var flag      = 1 ;

	if ( org == "-1" ){
		message = "Please select Organization";
		flag = 0;
		$('#org_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( role == "-1" ){
		message = "Please select Role";
		flag = 0;
		$('#role_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( username == "" ){
		message = "Please enter Name";
		flag = 0;
		$('#username').focus();
		$('.message').addClass('error').html(message);
	}

	if ( password == "" ){
		message = "Please enter password";
		flag = 0;
		$('#password').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}


	if ( flag == 1 ){
		console.log( formData );
		$.ajax({
			url  : serverUrl+'postUser.php',
			data : formData,
			method : 'POST',
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});

/*
* role Details
*/
function loadOrganization(){
	$.ajax({
		url  : serverUrl+'getOrganization.php',		
		method : 'GET',
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			var htm = '';
			if ( objData.code == 200 ){
				htm += '<option value="-1">---Organizations---</option>';
				$.each( objData.data, function( index, obj ){
					htm += '<option value="'+obj.id+'">'+ obj.name +'</option>';
				});
				$('#org_id').html(htm);
		    }
		   	if ( objData.code == 404 || objData.code == 405 ){	       	
	   			message = objData.data;
	   			$('.message').addClass('error').html(message);
	   		}	
	    },
	    error: function () {
	        if ( response.code == 401){
	       		window.location.replace('/');		       	
	        }
	        $('.message').addClass('error').html(message);
	    } 
	});
}

/*
* role Details
*/
function loadRoles(){
	$.ajax({
		url  : serverUrl+'getRoles.php',		
		method : 'GET',
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			var htm = '';
			if ( objData.code == 200 ){
				htm += '<option value="-1">---Roles---</option>';
				$.each( objData.data, function( index, obj ){
					htm += '<option value="'+obj.id+'">'+ obj.name +'</option>';
				});
				$('#role_id').html(htm);
		    }
		   	if ( objData.code == 404 || objData.code == 405 ){	       	
	   			message = objData.data;
	   			$('.message').addClass('error').html(message);
	   		}	
	    },
	    error: function () {
	        if ( response.code == 401){
	       		window.location.replace('/');		       	
	        }
	        $('.message').addClass('error').html(message);
	    } 
	});
}