/*
* ------------------------------------------------------------------------------
* User Main Category js file 
* Includes scripts for User Main Category
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/

/*
* Clear message 
*/

$(document).ready(function(){
	$('.message').html('');
});


/*
* opens edit modal on click event handler
*/
$(document).on('click','.showUser',function() {
	$('#editUserModal').modal('show');
	var active = $(this).attr('data-active');
	var uname = $(this).attr('data-uname');
	var email = $(this).attr('data-email');
	var mobile = $(this).attr('data-mobile');
	var role = $(this).attr('data-role');
	var org = $(this).attr('data-org');
	var iuser = $(this).attr('data-iuser');
	var opwd = $(this).attr('data-password');
	var id = $(this).attr('id');
	$('#mobile').val(mobile);	
	$('#email').val(email);	
	$('#active').val(active);	
	$('#uid').val(id);	
	$('#username').val(uname);	
	$('#old_password').val(opwd);	
	loadOrganization( org );
	loadRoles( role );
	$('#userTitle').html( 'Details of '+ uname );	
});


/*
* delete member click event
*/
$(document).on('click','.deleteUser',function() {
	var id = $(this).attr('data-id');	
	$.ajax({
		url  : serverUrl+'deleteUser.php',
		method : 'POST',
		data   : { 'id':id },
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			if( objData.code == 200 ){				
				message = objData.data;
				var url = objData.url;
		       	window.location.replace( url+'.php');
			}

			if( objData.code == 405 ){				
				message = objData.data;
			    $('.message').addClass('error').html(message);
			}
			
		}
	});
});

/*
* editSubCatBtn click event handler
*/
$(document).on('click','#editUser',function() {
	var username  = $('#username').val();	
	var password  = $('#password').val();	
	var role      = $('#role_id').val();	
	var org       = $('#org_id').val();	
	var active    = $('#active').val();
	var formData  = $('#editUserForm').serialize();
	var message   = '';
	var flag      = 1 ;

	if ( org == "-1" ){
		message = "Please select Organization";
		flag = 0;
		$('#org_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( role == "-1" ){
		message = "Please select Role";
		flag = 0;
		$('#role_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( username == "" ){
		message = "Please enter Name";
		flag = 0;
		$('#username').focus();
		$('.message').addClass('error').html(message);
	}

	if ( password == "" ){
		message = "Please enter password";
		flag = 0;
		$('#password').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}


	if ( flag == 1 ){
		console.log(formData);
		$.ajax({
			url  : serverUrl+'postUser.php',
			data : formData,
			method : 'POST',
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
					alert( message );
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});

/*
* role Details
*/
function loadOrganization( org_id ){
	$.ajax({
		url  : serverUrl+'getOrganization.php',		
		method : 'GET',
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			var htm = '';
			if ( objData.code == 200 ){
				htm += '<option value="-1">---Organizations---</option>';
				$.each( objData.data, function( index, obj ){
					if( org_id == obj.id ){
						htm += '<option value="'+obj.id+'" selected = "selected">'+ obj.name +'</option>';
					}else{
						htm += '<option value="'+obj.id+'">'+ obj.name +'</option>';
					}
				});
				$('#org_id').html(htm);
		    }
		   	if ( objData.code == 404 || objData.code == 405 ){	       	
	   			message = objData.data;
	   			$('.message').addClass('error').html(message);
	   		}	
	    },
	    error: function () {
	        if ( response.code == 401){
	       		window.location.replace('/');		       	
	        }
	        $('.message').addClass('error').html(message);
	    } 
	});
}

/*
* role Details
*/
function loadRoles( role_id ){
	$.ajax({
		url  : serverUrl+'getRoles.php',		
		method : 'GET',
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			var htm = '';
			if ( objData.code == 200 ){
				htm += '<option value="-1">---Roles---</option>';
				$.each( objData.data, function( index, obj ){
					if( role_id == obj.id ){
						htm += '<option value="'+obj.id+'" selected = "selected">'+ obj.name +'</option>';
					}else{
						htm += '<option value="'+obj.id+'">'+ obj.name +'</option>';
					}
				});
				$('#role_id').html(htm);
		    }
		   	if ( objData.code == 404 || objData.code == 405 ){	       	
	   			message = objData.data;
	   			$('.message').addClass('error').html(message);
	   		}	
	    },
	    error: function () {
	        if ( response.code == 401){
	       		window.location.replace('/');		       	
	        }
	        $('.message').addClass('error').html(message);
	    } 
	});
}