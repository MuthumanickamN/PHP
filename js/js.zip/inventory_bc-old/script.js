/*
* ------------------------------------------------------------------------------
* Product js file 
* Includes scripts for product
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/
/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');
	getOrganization();
	getSuppliers();
	getMainCat();	
	getTaxes();
});

/*
* newMember click event handler
*/
$(document).on('click','#addProduct',function() {
	var name  = $('#name').val();
	var batch_no  = $('#batch_no').val();
	var parent_id = $('#parent_id').val();
	var available_stock  = $('#available_stock').val();
	var child_id = $('#child_id').val();
	var landing_cost = $('#landing_cost').val();
	var supplier_id = $('#supplier_id').val();
	var active    = $('#active').val();
	var formData  =  new FormData($('#newProductForm')[0]);
	var message   = '';
	var flag      = 1 ;

	if ( name == "" ){
		message = "Please enter Name";
		flag = 0;
		$('#name').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}

	if ( parent_id == "-1" ){
		message = "Please select Main Category";
		flag = 0;
		$('#parent_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( child_id == "-1" ){
		message = "Please select Sub Category";
		flag = 0;
		$('#child_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( supplier_id == "-1" ){
		message = "Please select Supplier";
		flag = 0;
		$('#supplier_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( batch_no == "" ){
		message = "Please enter Batch";
		flag = 0;
		$('#batch_no').focus();
		$('.message').addClass('error').html(message);
	}

	if ( available_stock == "" ){
		message = "Please enter available stock";
		flag = 0;
		$('#available_stock').focus();
	}

	if ( tax == "-1" ){
		message = "Please select Tax";
		flag = 0;
		$('#tax').focus();
		$('.message').addClass('error').html(message);
	}

	if ( landing_cost == "" ){
		message = "Please enter landing cost";
		flag = 0;
		$('#landing_cost').focus();
	}


	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postProduct.php',
			data : formData,
			method : 'POST',
			processData: false,
    		contentType: false,
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});

/*
* delete member click event
*/
$(document).on('click','.deleteProduct',function() {
	var id = $(this).attr('data-id');
	console.log(id);
	$.ajax({
		url  : serverUrl+'deleteProduct.php',
		method : 'GET',
		data   : { 'id':id },
		success: function( response ) {
			console.log( response );
			var objData = JSON.parse( response );
			if( objData.code == 200 ){				
				message = objData.data;
				var url = objData.url;
				alert(message);
		       	window.location.replace( url+'.php');
			}

			if( objData.code == 405 ){				
				message = objData.data;
			    $('.message').addClass('error').html(message);
			}
			
		}
	});
});

/*
* loads the supplier based on selection
*/
function getSuppliers(){
	$.ajax({
			url  : serverUrl+'getSuppliers.php',
			method : 'GET',
			success: function( response ) {
				console.log( response);
				var objData = JSON.parse( response );
				var htm = '';
				htm += '<option value="-1">--- Supplier ---</option>';
				if ( objData.code == 200  ){
					$.each( objData.data,function( index, supplier ){
						htm += '<option value="' + supplier.id + '">'+ supplier.name + '</option>';
					});
					$('#supplier_id').html(htm);
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
}

/*
* loads the supplier based on selection
*/
function getOrganization(){
	$.ajax({
			url  : serverUrl+'getOrganization.php',
			method : 'GET',
			success: function( response ) {
				console.log( response);
				var objData = JSON.parse( response );
				var htm = '';
				htm += '<option value="-1">--- Organization ---</option>';
				if ( objData.code == 200  ){
					$.each( objData.data,function( index, org ){
						htm += '<option value="' + org.id + '">'+ org.name + '</option>';
					});
					$('#org_id').html(htm);
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
}

/*
* loads the main category based on selection
*/
function getMainCat(){
	$.ajax({
			url  : serverUrl+'getMainCat.php',
			method : 'GET',
			success: function( response ) {
				console.log( response);
				var objData = JSON.parse( response );
				var htm = '';
				htm += '<option value="-1">--- Main Category ---</option>';
				if ( objData.code == 200  ){
					$.each( objData.data,function( index, maincat ){
						htm += '<option value="' + maincat.id + '">'+ maincat.name + '</option>';
					});
					$('#parent_id').html(htm);
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
}


/*
* loads the attributes based on selection
*/
function getTaxes(){
	$.ajax({
			url  : serverUrl+'getTaxes.php',
			method : 'GET',
			success: function( response ) {
				console.log( response);
				var objData = JSON.parse( response );
				var htm = '';
				htm += '<option value="-1">--- Taxation ---</option>';
				if ( objData.code == 200  ){
					$.each( objData.data,function( index, tax ){
						htm += '<option value="' + tax.id + '">'+ tax.name + '</option>';
					});
					$('#tax').html(htm);
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
}

/*
* ponlc on change event
*/
$( document ).on( 'change', '#ponlc', function(){
	var ponlc = $(this).val();
	var landing_cost = $('#landing_cost').val();
	if( landing_cost == "" ){
		$('.message').addClass('error').html('Please fill landing cost first');
		$('#landing_cost').focus();
	}else{		
		var precentage = ( ponlc / 100 ) * landing_cost;
		$('#selling_cost').val( parseInt( landing_cost ) +  precentage  );
	}
});

/*
* landing_cost on change event
*/
$( document ).on( 'change', '#landing_cost', function(){
	$('.message').html('');
	var ponlc = $('#ponlc').val();
	if( ponlc == ""){
		$('.message').addClass('error').html('Please fill profit on landing cost');
		$('#ponlc').focus();
	}else{
		$('#ponlc').change().trigger();	
	}
});

/*
* Sub category
*/
$( document ).on( 'change', '#parent_id', function(){
	var parent_id = $(this).val();
	console.log( parent_id );
	$.ajax({
			url  : serverUrl+'getSubCat.php',
			method : 'GET',
			data: { parent_id : parent_id },
			success: function( response ) {
				console.log( response);
				var objData = JSON.parse( response );
				var htm = '';
				htm += '<option value="-1">--- Sub Category ---</option>';
				if ( objData.code == 200  ){
					$.each( objData.data,function( index, subcat ){
						htm += '<option value="' + subcat.id + '">'+ subcat.name + '</option>';
					});
					$('#child_id').html(htm);
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
});


/*
* generateBarcode
*/
$( document ).on( 'click', '#generatePcode', function(){	
	$.ajax({
		url  : serverUrl+'generatePcode.php',
		method : 'POST',		
		success: function( response ) {			
			console.log(response)
			var objData = JSON.parse( response );			
			$("#pcode").val( objData.data );
		},
		error: function () {
		    $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		}
	});
});