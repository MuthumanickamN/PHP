/*
* ------------------------------------------------------------------------------
* Product js file 
* Includes scripts for product
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/
var cnt = 1;

/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');
	getAttributes();
	getTaxes();
	generateCode();
	$('.consignee').hide();
});

$(document).on('click', '.add-row', function(){
    var htm = '';
    htm += '<tr>';
    htm += '<td width="25%" style="text-align:center; height:20px;"><input type="text" placeholder="Item" name="item[]" id="item_'+cnt+'" class="form-control"/></td>';
    htm += '<td width="8%" style="text-align:center; height:20px;"><input type="text" placeholder="HSN" name="hsn[]" id="hsn_'+cnt+'" class="form-control"/></td>';
    htm += '<td width="8%" style="text-align:center; height:20px;"><input type="text" placeholder="Qty" name="qty[]" id="qty_'+cnt+'" class="form-control"/></td>';
    htm += '<td width="10%" style="text-align:center; height:20px;"><input type="text" placeholder="Rate" name="rate[]" id="rate_'+cnt+'" class="form-control"/></td>';
    htm += '<td style="height:15px;" ><input type="text" placeholder="GST" data-index="'+cnt+'" name="gst[]" id="gst_'+cnt+'" class="gst form-control"/></td>';
    htm += '<td style="height:15px;" ><input type="text" placeholder="Discount" data-index="'+cnt+'" name="discount[]" id="discount_'+cnt+'" class="discount form-control"/></td>';    
    htm += '<td width="10%" style="text-align:center; height:20px;"><input type="text" data-index="'+cnt+'" placeholder="Total" name="total[]" id="total_'+cnt+'" class="form-control"/></td>';
    htm += '<td align="center">';
    htm += '<span class="icons"><a href="javascript:void(0);" class="add-row"><i class="fa fa-plus"></i></a></span>';
    htm += '<span class="icons"><a href="javascript:void(0);" class="delete-row">&nbsp;<i class="fa fa-trash"></i></a></span>';
    htm += '</td>';
    htm += '</tr>';
    $("table tbody").append(htm);
    cnt++;
});
        
// Find and remove selected table rows
$(document).on('click', '.delete-row', function(){
    $("table tbody").find('input[name="record"]').each(function(){
        if($(this).is(":checked")){
            $(this).parents("tr").remove();
        }
	});
});


/*
* same_consignee click event handler
*/
$(document).on('click','#same_consignee',function() {
	var val = $(this).val();
	if( val == '0'){
		$('.consignee').show();
		$('#is_consignee').show();
	}else if( val == '1' || val == "-1" ) {
		$('.consignee').hide();
		$('#is_consignee').hide();
	}
});


/*
* nCustomer click event handler
*/
$(document).on('click','.nCustomer',function() {
	$("#customer-item").modal('show');
	var type = $(this).attr('data-type');
	if( type == 1 ){
		$('#btype').val('1');
	}else{
		$('#btype').val('2');
	}
});

/*
* newMember click event handler
*/
$(document).on('click','#newInvoice',function() {
	var name  = $('#name').val();
	var formData  =  new FormData($('#tempInvoiceForm')[0]);
	var flag = 1;

	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postTempInvoice.php',
			data : formData,
			method : 'POST',
			processData: false,
    		contentType: false,
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});


/*
* loads the attributes based on selection
*/
function getAttributes(){
	$.ajax({
			url  : serverUrl+'getAttributes.php',
			method : 'GET',
			success: function( response ) {
				console.log( response);
				var objData = JSON.parse( response );
				var htm = '';
				htm += '<option value="-1">--- Attributes ---</option>';
				if ( objData.code == 200  ){
					$.each( objData.data,function( index, attr ){
						htm += '<option value="' + attr.id + '">'+ attr.name + '</option>';
					});
					$('#pattribute').html(htm);
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
}

/*
* loads the attributes based on selection
*/
function getTaxes(){
	$.ajax({
			url  : serverUrl+'getTaxes.php',
			method : 'GET',
			success: function( response ) {
				console.log( response);
				var objData = JSON.parse( response );
				var htm = '';
				htm += '<option value="-1">--- Taxation ---</option>';
				if ( objData.code == 200  ){
					$.each( objData.data,function( index, tax ){
						htm += '<option value="' + tax.id + '">'+ tax.name + '</option>';
					});
					$('#tax').html(htm);
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
}

/*
* loads the invoice code based on selection
*/
function generateCode() {	
	$.ajax({
		url  : serverUrl+'generateTempInvoiceCode.php',
		method : 'GET',		
		success: function( response ) {
			console.log( response );
			var objData = JSON.parse( response );
			if ( objData.code == 200  ){			
				$('.invoice_no').val( objData.data );
				$('#b_ino').val( objData.data );
				$('#printInvoice').attr( 'data-invoice', objData.data );
				$('#printEstimate').attr( 'data-invoice', objData.data );
				$('.nCustomer').attr('ino', objData.data );
		    }
		    else if ( objData.code == 405 ){
		    	message = objData.data;
		    	$('.message').addClass('error').html(message);
		    } 			    
		},
		error: function () {
		    $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		} 
	});
}

/*
* change event on QqCustomer click event handler
*/
$(document).on('click','#nCustomer',function() {			
	$("#customer-item").modal('show');     
});


$(document).on( 'click', '#addShop', function(){
	var branch    = $('#branch').val();
	var name      = $('#sname').val()
	var mobile    = $('#mobile').val();
	var active    = $('#active').val();
	var area      = $('#area_id').val();
	var formData  = $('#newShopForm').serialize();
	var message   = '';
	var flag      = 1 ;

	if ( name == "" ){
		message = "Please enter Shop name";
		flag = 0;
		$('#sname').focus();
		$('.message').addClass('error').html(message);
	}

	if ( branch == "-1" ){
		message = "Please select Branch";
		flag = 0;
		$('#branch').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}

	if ( area == "-1" ){
		message = "Please select Area";
		flag = 0;
		$('#area_id').focus();
		$('.message').addClass('error').html(message);
	}

	if ( mobile == "" ){
		message = "Please enter mobile";
		flag = 0;
		$('#mobile').focus();
		$('.message').addClass('error').html(message);
	}

	if ( ValidatePhone(mobile) == false ){
		message = "Please enter valid Mobile";
		flag = 0;
		$('#mobile').focus();
		$('.message').html(message);
	}


	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postConsigneeOrBuyer.php',
			data : formData,
			method : 'POST',
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;					
					console.log( objData.name );
					$('#qCustomerId').val( objData.id );
					alert( message );
					window.location.replace( objData.url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}
});

/*
* on change event on gst click event handler
*/
$(document).on('change','.gst',function() {			
	var gst = $(this).val();
	var index = $(this).attr('data-index');
	var rate = $('#rate_' +index ).val();
	var qty = $('#qty_' +index ).val();
	if( rate == "" ){
		$('.message').addClass('error').html('Enter the price');
	}else{
		var gstAmt = parseFloat(rate)*parseInt(gst)/100;
		var gstAmtTot = gstAmt*parseInt(qty);		
		var rateTot = parseFloat(rate)*parseInt(qty);		
		var total = parseFloat( rateTot ) + parseFloat( gstAmtTot );		
		$('#total_'+index).val( total );
	}
});

/*
* on change event on discount click event handler
*/
$(document).on('change','.discount',function() {			
	var discount = $(this).val();	
	var index = $(this).attr('data-index');
	var gst = $('#gst_'+index).val();
	var rate = $('#rate_' +index ).val();
	var qty = $('#qty_' +index ).val();
	if( rate == "" ){
		$('.message').addClass('error').html('Enter the price');
	}else{
		var gstAmt = rate*gst/100;
		var gstAmtTot = gstAmt*qty;		
		var rateTot = parseFloat(rate)*parseInt(qty);		
		var discountAmt = rateTot*discount/100;
		var total = ( rateTot + gstAmtTot ) - parseFloat( discountAmt );	
		$('#total_'+index).val( total );
	}
});

