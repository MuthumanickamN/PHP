/*
* ------------------------------------------------------------------------------
* Customers js file 
* Includes scripts for Customers
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/

/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');	
    $('[data-toggle="tooltip"]').tooltip(); 
	$.ajaxSetup({
    	headers: { 'access_token' : $('meta[name="access_token"]').attr('content') }
  	});
});

/*
* show post press
*/

$(document).on('click', '.showCustomer', function(){
	var id =  $(this).attr('id');
	window.location.replace('editCustomer.php?id=' + id );	
});

/*
* delete member click event
*/
$(document).on('click','.deleteAddress',function() {
	var id = $(this).attr('id');
	var cust = $(this).attr('data-customer');
	console.log(id);
	$.ajax({
		url  : serverUrl+'deleteDeliveryAddress.php',
		method : 'GET',
		data   : { 'id':id, 'cust' :cust },
		success: function( response ) {
			console.log( response );
			var objData = JSON.parse( response );
			if( objData.code == 200 ){				
				message = objData.data;
				var url = objData.url;
				alert(message);
		       	window.location.replace( url+'.php?id='+cust);
			}

			if( objData.code == 405 ){				
				message = objData.data;
			    $('.message').addClass('error').html(message);
			}
			
		}
	});
});

/*
* clear messages in tab click
*/
$(document).on( 'click', '.tab-link', function(){
    $('.message').html('');
    if( localStorage.getItem('customer_id') != null && localStorage.getItem('customer_id') != "" ){
        var customer = localStorage.getItem('customer_id');
        $('#cust_id').val( customer );
    }
});

/*
* edit customer event
*/
$(document).on( 'click', '#custDetails', function() {
    var name       = $('#cname').val();
    var phone      = $('#phone').val();
    var email      = $('#email').val();
    var is_company = $('#is_company').val();
    var flag     = 1;
    if( name == "" ){
        message = "Please enter name";
        flag = 0;
        $('#cname').focus();
        $('.message').addClass('error').html(message);
    }
    if( phone == "" ){
        message = "Please enter phone";
        flag = 0;
        $('#phone').focus();
        $('.message').addClass('error').html(message);
    }
    if( email == "-1" ){
        message = "Please select batch email";
        flag = 0;
        $('#email').focus();
        $('.message').addClass('error').html(message);
    }
    if( is_company == "-1" ){
        message = "Please select Is company";
        flag = 0;
        $('#is_company').focus();
        $('.message').addClass('error').html(message);
    }
    if( flag == 1 ){
        var fData = $('#editCustomerDetails').serialize();
        console.log(fData)
        $.ajax({
            url  : serverUrl+'updateCompanyDetails.php',
            method : 'POST',
            data: fData,
            success: function( response ) { 
                console.log( response );
                var objData = JSON.parse( response );                                
                if( objData.code == 200 ) {   
                    message = objData.data;                           
                    $('.message').addClass('success').html(message);
                }
                if ( objData.code == 401 || objData.code == 404 || objData.code == 405 ){                             
                    message = objData.data;                            
                    $('.message').addClass('error').html(message);
                } 
            },
            error: function () {
                $('.message').addClass('error').html('Request Failed. Cannot connect to server');
            }   
        });      
    }
});

/*
* opens edit modal on click event handler
*/
$(document).on('click','.showAddress',function() {
	$('#editAddressModal').modal('show');
	var active = $(this).attr('data-active');	
	var id = $(this).attr('id');
	var building = $(this).attr('data-building');	
	var street = $(this).attr('data-street');	
	var city = $(this).attr('data-city');	
	var state = $(this).attr('data-state');	
	var country = $(this).attr('data-country');	
	var pin = $(this).attr('data-pincode');	
	var cust = $(this).attr('data-customer');	
	var lm = $(this).attr('data-landmark');	
	var def= $(this).attr('data-def');	
	$('#d_is_default').val(def);		
	$('#active').val(active);	
	$('#aId').val(id);	
	$('#building').val(building);		
	$('#d_city').val(city);		
	$('#d_state').val(state);		
	$('#d_country').val(country);		
	$('#street').val(street);		
	$('#landmark').val(lm);		
	$('#d_pincode').val(pin);		
	$('#addressTitle').html( 'Address of '+ cust );	
});

/*
* Address edit customer event
*/
$(document).on( 'click', '#editAddressDetails', function() {
    var flag = 1
    if( flag == 1 ){
        var fData = $('#editAddressForm').serialize();        
        $.ajax({
            url  : serverUrl+'updateAddressDetails.php',
            method : 'POST',
            data: fData,
            success: function( response ) { 
                console.log( response );
                var objData = JSON.parse( response );                                
                if( objData.code == 200 ) {   
                    message = objData.data;                           
                    $('.da-message').addClass('success').html(message);
                }
                if ( objData.code == 401 || objData.code == 404 || objData.code == 405 ){                             
                    message = objData.data;                            
                    $('.da-message').addClass('error').html(message);
                } 
            },
            error: function () {
                $('.da-message').addClass('error').html('Request Failed. Cannot connect to server');
            }   
        });      
    }
});

/*
* opens new address modal on click event handler
*/
$(document).on('click','.newDa',function() {
    $('#newAddressModal').modal('show');
    var cust = $(this).attr('data-customer');    
    $('#aTitle').html( 'New delivery address for '+ cust ); 
});

/*
* Address edit customer event
*/
$(document).on( 'click', '#newAddressDetails', function() {
    var flag = 1
    if( flag == 1 ){
        var fData = $('#newAddressForm').serialize();        
        $.ajax({
            url  : serverUrl+'postAddressDetails.php',
            method : 'POST',
            data: fData,
            success: function( response ) { 
                console.log( response );
                var objData = JSON.parse( response );                                
                if( objData.code == 200 ) {   
                    message = objData.data;                           
                    $('.da-message').addClass('success').html(message);
                }
                if ( objData.code == 401 || objData.code == 404 || objData.code == 405 ){                             
                    message = objData.data;                            
                    $('.da-message').addClass('error').html(message);
                } 
            },
            error: function () {
                $('.da-message').addClass('error').html('Request Failed. Cannot connect to server');
            }   
        });      
    }
});