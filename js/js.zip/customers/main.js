/*
* ------------------------------------------------------------------------------
* Customers js file 
* Includes scripts for Customers
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/

/*
* Clear message 
*/

var cnt = 2;

$(document).ready(function(){
    $.ajaxSetup({
        headers: { 'access_token' : $('meta[name="access_token"]').attr('content') }
    });
    $('.message').html('');    
    $('.password').hide();
    $('.username').hide();
});

/* Adding more address fieldsets */
$(document).on( 'click', '.add-more', function(){
    var htm = '';
    htm += '<fieldset class="col-md-12" id="address_'+cnt+'">';
    htm += '<div class="col-md-12">';
    htm += '<div class="col-lg-11"><lable class="control-label fcolor uppercase">Address '+ cnt +'</lable></div>';
    htm += '<div class="col-lg-1"><a href="javascript:script(0);" class="add-more"><i class="fa fa-plus"></i></a>&nbsp;&nbsp;';
    htm += '<a href="javascript:script(0);" data-id="address_'+cnt+'" class="remove"><i class="fa fa-close"></i></a></div>';
    htm += '</div><hr/>';    
    htm += '<div class="col-md-6">';
    htm += '<div class="form-group">';
    htm += '<div class="col-md-12">';
    htm += '<input id="building_'+cnt+'" type="text" class="form-control" name="building[]" value="" placeholder="Building Name / No" />';
    htm += '</div>';
    htm += '</div>';
    htm += '<div class="form-group">';
    htm += '<div class="col-md-12">';
    htm += '<input type="text" class="form-control" name="street[]" id="street_'+cnt+'" placeholder="Street" />';
    htm += '</div>';
    htm += '</div>';
    htm += '<div class="form-group">';
    htm += '<div class="col-md-12">';
    htm += '<input type="text" class="form-control" name="pincode[]" id="pincode_'+cnt+'" placeholder="Pincode" />';
    htm += '</div>';
    htm += '</div>';
    htm += '<div class="form-group">';
    htm += '<div class="col-md-12">';
    htm += '<input type="text" class="form-control" name="country[]" id="country_'+cnt+'" value="India" placeholder="Country" />';
    htm += '</div>';
    htm += '</div>';
    htm += '</div>';
    htm += '<div class="col-md-6">';
    htm += '<div class="form-group">';
    htm += '<div class="col-md-12">';
    htm += '<input type="text" class="form-control" name="city[]" id="city_'+cnt+'" placeholder="City">';
    htm += '</div>';
    htm += '</div>';
    htm += '<div class="form-group">';
    htm += '<div class="col-md-12">';
    htm += '<input type="text" class="form-control" name="state[]" id="state_'+cnt+'" value="Tamilnadu" placeholder="State" />';
    htm += '</div>';
    htm += '</div>';
    htm += '<div class="form-group">';
    htm += '<div class="col-md-12">';
    htm += '<input type="text" class="form-control" name="landmark[]" id="landmark_'+cnt+'" placeholder="Landmark" />';
    htm += '</div>';
    htm += '</div>';
    htm += '<div class="form-group">';
    htm += '<div class="col-md-12">';
    htm += '<select id="is_default_'+cnt+'" name="is_default[]" class="form-control">';
    htm += '<option value="-1">---Is Default?---</option>';
    htm += '<option value="1">Yes</option>';
    htm += '<option value="0">No</option>';
    htm += '</select>';
    htm += '</div>';
    htm += '</div>';
    htm += '</div>';
    htm += '</fieldset>';
    $('.extraAddress').append(htm);
    cnt = cnt+1;
});

/*
* Remove address fieldset
*/
$( document ).on( 'click', '.remove', function(){
    var id = $(this).attr('data-id');
    $('#'+id ).remove();
});


/*
*  loads order on page load
*/
function generateCustomerId(){
    var user = $('#user_id').val();
    var org  = $('#org_id').val();    
    $.ajax({
        url  : serverUrl+'generateCustomerCode.php',
        method : 'POST',
        data: { 'userid' : user, 'orgid' : org },
        success: function( response ) {
            console.log( response );
            var objData = JSON.parse( response );            
            console.log( objData.CUST_ID );
            if ( objData.code == 200 ){
                $('.customer_id').val( objData.CUST_ID ).attr('readonly', true );
            }
            if ( objData.code == 404 || objData.code == 405 ){          
                message = objData.data;
                $('.message').addClass('error').html(message);
            }
        },
        error: function () {
            $('.message').addClass('error').html('Request Failed. Cannot connect to server');
        } 
    });
}

/*
* change event on is_company
*/
$(document).on( 'change', '#is_company', function(){
    var val = $(this).val();
    console.log( val );
    if( val == 1 || val == -1 ){
        $('.password').hide();
        $('.username').hide();
    }else {
        $('.password').show();
        $('.username').show();
    }
});

/*
* Add customer event
*/
$(document).on( 'click', '#cDetails', function() {
    var name       = $('#cname').val();
    var phone      = $('#phone').val();
    var email      = $('#email').val();
    var is_company = $('#is_company').val();
    var flag     = 1;
    if( name == "" ){
        message = "Please enter name";
        flag = 0;
        $('#cname').focus();
        $('.message').addClass('error').html(message);
    }
    if( phone == "" ){
        message = "Please enter phone";
        flag = 0;
        $('#phone').focus();
        $('.message').addClass('error').html(message);
    }
    if( email == "-1" ){
        message = "Please select batch email";
        flag = 0;
        $('#email').focus();
        $('.message').addClass('error').html(message);
    }
    if( is_company == "-1" ){
        message = "Please select Is company";
        flag = 0;
        $('#is_company').focus();
        $('.message').addClass('error').html(message);
    }
    if( flag == 1 ){
        var fData = $('#customerDetails').serialize();
        $.ajax({
            url  : serverUrl+'postCompanyDetails.php',
            method : 'POST',
            data: fData,
            success: function( response ) { 
                console.log( response );
                var objData = JSON.parse( response );                                
                if( objData.code == 200 ) {   
                    message = objData.data;       
                    var customer = objData.customer_id;                    
                    localStorage.setItem( 'customer_id', customer );                    
                    $('.message').addClass('error').html(message);
                }
                if ( objData.code == 404 || objData.code == 405 ){                             
                    message = objData.data;                
                    $('.message').addClass('error').html(message);
                } 
            },
            error: function () {
                $('.message').addClass('error').html('Request Failed. Cannot connect to server');
            }   
        });      
    }
});

/*
* clear messages in tab click
*/
$(document).on( 'click', '.tab-link', function(){
    $('.message').html('');
    if( localStorage.getItem('customer_id') != null && localStorage.getItem('customer_id') != "" ){
        var customer = localStorage.getItem('customer_id');
        $('#cust_id').val( customer );
    }
});

/*
* Add customer event
*/
$(document).on( 'click', '#aDetails', function() {
    var flag = 1;
    if( flag == 1 ){
        var fData = $('#addressDetails').serialize();
        $.ajax({
            url  : serverUrl+'postAddressDetails.php',
            method : 'POST',
            data: fData,
            success: function( response ) { 
                console.log( response );
                var objData = JSON.parse( response );                                
                if( objData.code == 200 ) {   
                    message = objData.data;                
                    $('.message').addClass('success').html(message);
                }
                if ( objData.code == 404 || objData.code == 405 ){                             
                    message = objData.data;                
                    $('.message').addClass('error').html(message);
                } 
            },
            error: function () {
                $('.message').addClass('error').html('Request Failed. Cannot connect to server');
            }   
        });      
    }
});
