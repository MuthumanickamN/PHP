/*
* ------------------------------------------------------------------------------
* Role js file 
* Includes scripts for role
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/
/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');
});

/*
* newRoleclick event handler
*/
$(document).on('click','#addRole',function() {	
	var name      = $('#qrole').val();	
	var active    = $('#active').val();		
	var formData  = $('#newRoleFrom').serialize();
	var message   = '';
	var flag      = 1 ;

	if ( name == "" ){
		message = "Please enter Role Name";
		flag = 0;
		$('#name').focus();
		$('.message').addClass('error').html(message);
	}

	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postRole.php',
			data : formData,
			method : 'POST',
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
					alert( message );
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});

/*
* delete member click event
*/
$(document).on('click','.deleteRole',function() {
	var id = $(this).attr('id');
	$.ajax({
		url  : serverUrl+'deleteRole.php',
		method : 'GET',
		data   : { 'id':id },
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			if( objData.code == 200 ){				
				message = objData.data;
				alert( message );
				var url = objData.url;
		       	window.location.replace( url+'.php');
			}

			if( objData.code == 405 ){				
				message = objData.data;
			    $('.message').addClass('error').html(message);
			}
			
		}
	});
});

/*
* editSubCatBtn click event handler
*/
$(document).on('click','#editRoleBtn',function() {
	var name      = $('#role').val();		
	var formData  = $('#editRoleForm').serialize();
	var message   = '';
	var flag      = 1 ;

	if ( name == "" ){
		message = "Please enter Role Name";
		flag = 0;
		$('#qrole').focus();
		$('.message').addClass('error').html(message);
	}

	if ( flag == 1 ){
		console.log(formData);
		$.ajax({
			url  : serverUrl+'postRole.php',
			data : formData,
			method : 'POST',
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
					alert( message );
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}
});

/*
* opens edit modal on click event handler
*/
$(document).on('click','#showRole',function() {
	$('#editRoleModal').modal('show');
	var active = $(this).attr('data-active');	
	var id = $(this).attr('data-id');
	var role = $(this).attr('data-role');	
	$('#status').val(active);	
	$('#rId').val(id);	
	$('#role').val(role);		
	$('#roleTitle').html( 'Details of '+ role );	
});
