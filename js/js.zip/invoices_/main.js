/*
* ------------------------------------------------------------------------------
* Invoices js file 
* Includes scripts for Invoices
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/

/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');	
});

function getInvoiceItems( inv_no ){
	$.ajax({
		url  : serverUrl+'getInvoiceDetails.php',
		method : 'POST',
		data: { 'ino' : inv_no, 'type' : 'invoice' },
		success: function( response ) {
			console.log( response );
			var objData = JSON.parse( response );
			var inv_dt = '';
			var cust_name = '';
			var cust_id = '';
			var consignment_id = '';
			var htm = '';			
			$.each( objData.invoiceData, function( index, obj ){
				inv_dt = formatDateTime( obj.invoice_date);
				cust_name = obj.cust_name;
				cust_id = obj.cust_id;
				consignment_id = obj.consignment_id;
				htm += ' <tr>';
				htm += ' <td width="35%" style="text-align:center; height:20px;"><input type="text" value="'+obj.item+'" name="item[]" id="item_'+index+'" class="form-control" data-index="'+index+'"/>';
				htm += ' <input type="hidden" value="'+obj.row_id+'" name="row_id[]" id="row_id_'+index+'" class="form-control" data-index="'+index+'"/>';
				htm += ' </td>';
				htm += ' <td width="15%" style="text-align:center; height:20px;"><input type="text" value="'+obj.hsn+'" name="hsn[]" id="hsn_'+index+'" class="form-control" data-index="'+index+'"/></td>';
				htm += ' <td width="10%" style="text-align:center; height:20px;"><input type="text" value="'+obj.quantity+'" name="quantity[]" id="qty_'+index+'" class="form-control qty" data-index="'+index+'"/></td>';
				htm += ' <td width="20%" style="text-align:center; height:20px;"><input type="text" value="'+obj.rate+'" name="rate[]" id="rate_'+index+'" class="form-control price" data-index="'+index+'"/></td>';
				htm += ' <td width="10%" style="text-align:center; height:20px;"><input type="text" value="'+obj.gst+'" name="gst[]" id="gst_'+index+'" class="form-control gst" data-index="'+index+'"/></td>';
				htm += ' <td width="20%" style="text-align:center; height:20px;"><input type="text" value="'+obj.total+'" name="total[]" id="total_'+index+'" class="form-control" data-index="'+index+'"/></td>';
				//htm += ' <td align="center"><span class="icons"><a href="javascript:void(0);" class="add-row"><i class="fa fa-plus"></i></a></span></td>';
				//htm += ' <td align="center"><span class="icons"><span class="icons"><a href="javascript:void(0);" class="delete-row"><i class="fa fa-trash"></i></a></span></td>';
				htm += ' </tr>';
				cnt = index + 1;
			});			
			$('#invoice_dt').val(inv_dt);
			$('#customer').val(cust_name);
			$('#customer_id').val(cust_id);
			$('#e_con_id').val( consignment_id );
			$("table tbody").append(htm);
		},
		error: function () {
		    $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		} 
	});
}

$(document).on( 'click', '#getInvoiceDetails', function(){	
	var inv_no = $('#eino').val();
	getInvoiceItems( inv_no );
});


$(document).on( 'click', '#btnConsDetails', function(){	
	var inv_no = $('#eino').val();
	$.ajax({
		url  : serverUrl+'getInvoiceDetails.php',
		method : 'POST',
		data: { 'ino' : inv_no, 'type' : 'consignment' },
		success: function( response ) {
			console.log( response );
			var bl_no = '';
			var be_no = '';
			var inv_no = '';
			var bl_dt = '';
			var be_dt = '';
			var inv_dt = '';
			var weight_uom = '';
			var weight = '';
			var container_no = '';
			var container_type = '';
			var no_of_packs = '';
			var packs_uom = '';
			var commodity = '';
			var frieght_no = '';
			var ino = '';
			var objData = JSON.parse( response );
			$.each( objData.consigmentData, function( index, obj ){
				bl_no = obj.bl_no;				
				bl_dt = obj.bl_dt;
				be_no = obj.be_no;
				be_dt = obj.be_dt;				
				inv_no = obj.inv_no;
				inv_dt = obj.inv_dt;
				weight = obj.weight;
				weight_uom = obj.weight_uom;			
				container_type = obj.container_type;
				container_no = obj.container_no;
				no_of_packs = obj.tot_packs;
				packs_uom = obj.pk_uom;
				commodity = obj.commodity;
				frieght_no = obj.fno;
				ino = obj.ino;
			});
			$('#bl_no').val( bl_no );
			$('#bl_dt').val( formatDateTime( bl_dt ) );

			$('#be_dt').val( formatDateTime( be_dt ) );
			$('#be_no').val( be_no );

			$('#inv_no').val( inv_no );
			$('#inv_dt').val( formatDateTime( inv_dt ) );

			$('#weight').val( weight );
			$('#weight_uom').val( weight_uom );

			$('#container_no').html( container_no );
			$('#container_type').html( container_type );

			$('#packs').val( no_of_packs );
			$('#packs_uom').val( packs_uom );
			$('#commodity').val( commodity );
			$('#e_consignment_no').val( frieght_no );
			$('#e_consignment_no').val( frieght_no );			
		},
		error: function () {
		    $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		} 
	});
});


function formatDateTime(input){
	var iDate = new Date( 1000*input );
    iDate = iDate.toLocaleString();    
    var dtStr = iDate.split(",");
    var dt = dtStr[0].split("/");
    console.log( dt )
    var day = '';
    var month = '';
    if( dt['0'] >= 1 && dt['0'] <= 9 ){
    	month = '0'+dt['0']
    }else{
    	month = dt['0'];
    }
    if( dt['1'] >= 1 && dt['1'] <= 9 ){
    	day = '0'+dt['1'];
    }else{
    	day = dt[1];
    }
    return  dt['2']+'-'+ month +'-'+day;
}

/*
* onchange quantity
*/
$( document ).on( 'change', '.price', function(){
		$('.message').html('');
		var inx = $(this).attr('data-index');
		var gst = $('#gst_'+inx ).val();
		console.log( gst );				
		var price  = $(this).val();
		console.log( price );						
		var quantity = $( '#qty_'+inx ).val();	
		console.log( inx + '------' + quantity );	
		var subtotal = parseInt(quantity)*parseFloat(price);				
		var total  = subtotal + ( subtotal * gst / 100 );
		console.log( total );
		subtotal = parseFloat(total).toFixed(2);
		$('#total_'+inx).val(total);
});

/*
* onchange quantity
*/
$( document ).on( 'change', '.qty', function(){
		$('.message').html('');
		var inx = $(this).attr('data-index');
		var gst = $('#gst_'+inx ).val();
		console.log( gst );				
		var price  = $('#rate_'+inx ).val();
		console.log( price );						
		var quantity = $(this).val();	
		console.log( inx + '------' + quantity );	
		var subtotal = parseInt(quantity)*parseFloat(price);				
		var total  = subtotal + ( subtotal * gst / 100 );
		console.log( total );
		subtotal = parseFloat(total).toFixed(2);
		$('#total_'+inx).val(total);
});


$(document).on('click','#invDetails',function() {
	var name  = $('#name').val();
	var formData  =  new FormData($('#invoiceDetails')[0]);
	var flag = 1;

	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'updateTempInvoice.php',
			data : formData,
			method : 'POST',
			processData: false,
    		contentType: false,
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;		       		
					$('.message').addClass('success').html(message);
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});


/*
* consignment click event handler
*/
$(document).on('click','#conginDetails',function() {
	var name  = $('#name').val();
	var formData  =  new FormData($('#editConsignmentForm')[0]);
	var flag = 1;

	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'updateConsignment.php',
			data : formData,
			method : 'POST',
			processData: false,
    		contentType: false,
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;		       		
					alert(message);
					window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});
