/*
* ------------------------------------------------------------------------------
* Employee js file 
* Includes scripts for Employee
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/
/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');
});

/*update Event*/

$(document).on('click','#editPo',function() {
	var num  = $('#num').val();
	var flag = 1;
	if ( num == "" ){
		message = "Please enter Po Number";
		flag = 0;
		$('#num').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}

	
	if ( flag == 1 ){
		var fData = new FormData( $('#editPoForm')[0] );		
		$.ajax({
			url  : serverUrl+'postPo.php',
			data : fData,
			method : 'POST',
			processData : false,
			contentType: false,
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}
 
});

/*
* delete PO click event
*/
$(document).on( 'click', '.deletePo', function() {
	var id = $(this).attr('data-id');
	$.ajax({
		url  : serverUrl+'deletePo.php',		
		method : 'POST',		
		data : { 'po_no' : id },
		success: function( response ) {
			console.log(response);
			var objData = JSON.parse( response );
			if ( objData.code == 200  ){
				message = objData.data;
				var url = objData.url;
		    	window.location.replace( url+'.php');
			}else if ( objData.code == 401 ){
			   	message = objData.data;
			   	$('.message').addClass('error').html(message);
			} else if ( objData.code == 405 ){
			    message = objData.data;
			    $('.message').addClass('error').html(message);
			 } 			    
		},error: function () {
		    $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		} 
	});
});