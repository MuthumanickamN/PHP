/*
* ------------------------------------------------------------------------------
* po js file 
* Includes scripts for po
* Author Dinesh Kumar Muthukrishnan 
* -------------------------------------------------------------------------------
*/


$(document).ready(function()  {
  $.ajaxSetup({
    headers: { 'access_token' : $('meta[name="access_token"]').attr('content') }
  });
});


/*
* Clear message 
*/
$(document).ready(function(){
	$('.message').html('');
	getBranches();
});

/*
* newMember click event handler
*/
$(document).on('click','#addPo',function() {
	var num           = $('#po_num').val();
	var active        = $('#active').val();
	var start_date    = $('#start_date').val();
	var end_date      = $('#end_date').val();
	var formData      = new FormData( $('#newPoForm')[0]);
	var message       = '';
	var flag          = 1 ;

	if ( num == "" ){
		message = "Please enter PO Number";
		flag = 0;
		$('#po_num').focus();
		$('.message').addClass('error').html(message);
	}

	if ( start_date == "" ){
		message = "Please enter Dtart Date";
		flag = 0;
		$('#start_date').focus();
		$('.message').addClass('error').html(message);
	}

	if ( end_date == "" ){
		message = "Please enter end date";
		flag = 0;
		$('#end_date').focus();
		$('.message').addClass('error').html(message);
	}

	if ( active == "-1" ){
		message = "Please select Active";
		flag = 0;
		$('#active').focus();
		$('.message').addClass('error').html(message);
	}

	if ( flag == 1 ){
		$.ajax({
			url  : serverUrl+'postPo.php',
			data : formData,
			method : 'POST',
			processData: false,
			contentType: false,
			success: function( response ) {
				console.log(response);
				var objData = JSON.parse( response );
				if ( objData.code == 200  ){
					message = objData.data;
					var url = objData.url;
		       		window.location.replace( url+'.php');
			    }else if ( objData.code == 401 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
		});
	}

});


/*
* loads the branch based on selection
*/
function getBranches() {
	var user     = $('#user_id').val();
    var org      = $('#org_id').val();
	$.ajax({
		url  : serverUrl+'getOrgCustPO.php',
		method : 'POST',
        data: { 'user_id' : user, 'org_id' : org },
			success: function( response ) {
				console.log( response );
				var objData = JSON.parse( response );
				var htm = '';
				htm += '<option value="-1">---Customer---</option>';
				if ( objData.code == 200  ){
					$.each( objData.data,function( index, branch ){
						htm += '<option value="' + branch.id + '">'+ branch.company_name + '</option>';
					});
					$('#cust_id').html(htm);
			    }
			    else if ( objData.code == 405 ){
			    	message = objData.data;
			    	$('.message').addClass('error').html(message);
			    } 			    
		    },
		    error: function () {
		        $('.message').addClass('error').html('Request Failed. Cannot connect to server');
		    } 
	});
}