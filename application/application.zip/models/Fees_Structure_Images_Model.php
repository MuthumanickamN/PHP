<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Fees_Structure_Images_Model extends CI_Model {


	function __construct()
	{
		parent::__construct();
	}
}
