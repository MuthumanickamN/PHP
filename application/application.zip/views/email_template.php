<!DOCTYPE html>
<html>
<head>
<title>Hello world</title>
</head>
<body>
Hi, Your email id is <?php echo $email; ?>
</body>
</html>