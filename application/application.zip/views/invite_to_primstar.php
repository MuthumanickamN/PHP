<section class="content-header">
<h1>Invite to Primestar</h1>
<ol class="breadcrumb">
<li><i class="fa fa-ticket" aria-hidden="true"></i> Promote</li>
<li class="active">Invite to Primestar</li>
</ol>
</section>
<!-- Main content -->
<!-- Main content -->
<section class="content admin_table">
<h3 class="mar_0">Invite User to Primestar</h3>
<div class="col-sm-12 col-md-4 col-lg-5 pad_top_20">
<input type="text" placeholder="Mobile Number">
</div>
<div class="col-sm-12 col-md-4 col-lg-2 pad_top_20">
<button type="button" class="btn btn-primary"><i class="fa fa-paper-plane" aria-hidden="true"></i> &nbsp; Send Invite</button>
</div>
<div class="clearfix"></div>
</section>
<!-- /.content -->
