<!DOCTYPE html>  
<script src='https://www.google.com/recaptcha/api.js'></script>
<script src='https://www.google.com/recaptcha/api.js?hl=es'></script>
<html>  
    <head>  
        <title>Hello World</title>  
    </head>  
    <body style="background-image: url('images/pk6.jpg');"> 
     <p>Hello World!
     <br/>
     <div class="g-recaptcha" data-sitekey="6LcePAATAAAAAGPRWgx90814DTjgt5sXnNbV5WaW"></div></p>
    </body>  
</html>