<?php $this->load->view('includes/header3'); ?>
 <html>
 <body>
 <head>
  <title>Registration Approval</title>
</head>

<div class="app-content content">
<div class="content-overlay"></div>
<div class="content-wrapper">
  <div class="content-header row">
    <div class="content-header-left col-md-6 col-12 mb-2">
      <h3 class="content-header-title" style="color: green">Academy Activities</h3>
      <div class="row breadcrumbs-top">
        <div class="breadcrumb-wrapper col-12">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Academy Activities</a>
            </li>
            <li class="breadcrumb-item"><a href="#">Registration Approval</a>
            </li>
           
          </ol>
        </div>
      </div>
    </div>
  </div>
<div class="content-body"><!-- Zero configuration table -->
<section id="configuration">
<div class="row">
<div class="col-12">
<div class="card">
<div class="card-header">
<h4 class="card-title">Registration  Approval</h4>
<a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>

</div>

<div class="panel panel-info" style="margin-top:20px; margin-left:20px;">
	<div class="row input-daterange">
		<div class="col-md-3 col-md-offset-2 ">
			<input type="text" name="start_date" id="start_date" class="form-control" />
			<span class="errorMsg"></span>
		</div>
		<div class="col-md-3">
			<input type="text" name="end_date" id="end_date" class="form-control" />
			
		</div>
		</div>
		<div class="col-md-3">
			<input type="button" name="select_listing" id="select_listing" value="Search" class="btn btn-info" />
			
		</div>
	
</div>


<div class="card-content">
<div class="card-body card-dashboard">
   
    <div class="table-responsive">
        <table id="example1" class="table table-striped table-bordered dt-responsive nowrap" border="0" cellpadding="0" cellspacing="0" style="width:100%">
            <thead>
                <tr>
                  <th style="text-align: center">S.No</th>
                  <th style="text-align: center">Student Name</th>
                  <th style="text-align: center">Parent Name</th>
                  <th style="text-align: center">Activity</th>
                  <th style="text-align: center">Contact Form</th>
                  <th style="text-align: center">Contact To</th>
                  <th style="text-align: center">Vat Amount</th>
                  <th style="text-align: center">Net Amount</th>
                  <th style="text-align: center">Payment View</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
<!-- confirm modal -->
<div class="modal" id="confirmModal" style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content panel panel-primary">
            <div class="modal-header panel-heading">
                    <h4 class="modal-title -remove-title">Confirmation</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
            <div class="modal-body" id="confirmMessage">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" id="confirmOk">Ok</button>
                <button type="button" class="btn btn-danger" id="confirmCancel">Cancel</button>
            </div>
        </div>
    </div>
</div>

</body>
</html>


<script type="text/javascript" language="javascript" >
var base_url = "<?php echo base_url(); ?>";
$(function () {
 $('.input-daterange').datepicker({
  todayBtn:'linked',
  format: "yyyy-mm-dd",
  autoclose: true
 });
 
	contact_listing();
});


jQuery(document).on('click','#select_listing', function(e){

	var start_date= $("#start_date").val(); 
	var end_date = $("#end_date").val(); 
	

  	contact_listing(start_date,end_date);
}); 

function contact_listing(start_date="",end_date=""){

    $('#example1').DataTable( {
       
            "columnDefs": [
                {"className": "dt-center"}
              ],
        
            "searching": true,
            "processing": true,
            "serverSide": true,
            oLanguage: {
               // sProcessing: "<img src='"+base_url+"images/admin/loadingroundimage.gif' style='width:40px; height:40px;'>"
            },
           "ajax": {
                "url": base_url+'Contact_details/contact_listing',
                "type": 'POST',
				"data":{start_date : start_date,end_date:end_date},
                
            },
             "bDestroy": true
        });  

}



</script>


<script type="text/javascript">
  function changestatus(id,field,value){
    confirmDialog('Are you sure to change the approval status?', function(){
        jQuery.ajax({
            type:'POST',
            url:baseurl+'index.php/Students/changestatus/'+id+'/'+field+'/'+value,
            dataType:'json',    
                   
            success: function (json) {
                $('.text-danger').remove();
                if(json['status']){
                    if(json['status']=='success'){
                        location.reload();
                    }
                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
            }          
        });
    });
}
function confirmDialog(message, onConfirm){
    var fClose = function(){
        modal.modal("hide");
    };
    var modal = $("#confirmModal");
    modal.modal("show");
    $('.modal-backdrop').addClass('show');
    $('.modal-backdrop').addClass('in');
    $("#confirmMessage").empty().append(message);
    $("#confirmOk").unbind().one('click', onConfirm).one('click', fClose);
    $("#confirmCancel").unbind().one("click", fClose);
}
</script>

