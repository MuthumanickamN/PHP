<?php 

defined('BASEPATH') OR exit('No direct script access allowed'); 

  
class Activity_Selections extends CI_Controller {  
      
    
	public function __construct(){
		parent::__construct();
		//$this->load->model('Default_Model', 'default');
		$this->load->model('School_profile_report_Model', 'schools');
		//$this->load->model('Daily_Transaction_Model', 'transaction');
	}
	public function edit($id, $eid, $from=0)
	{
	     
		$query = $this->db->query('select a.*, g.game, p.parent_code from activity_selections a 
		left join games g on game_id=a.activity_id 
		left join parent p on p.parent_id=a.parent_user_id where a.id='.$id);
    	$data=$query->row_array();
    	$data['back_url'] =$eid;
    	$data['activity_selection_id'] =$id;
    	$data['title'] ="Activity Selections";
    	$data['from'] =$from;
		
		$data['activityList'] = $this->schools->getAllActivityList();
    	
    	$query2 = $this->db->query("select * from game_levels order by games_level_id asc");
    	$data['levels']=$query2->result_array();
    	
    	$query3 = $this->db->query("select * from coach where role='Head coach' and deleted=0  and activity_id='".$data['activity_id']."'");
    	$data['head_coaches']=$query3->result_array();
    	
    	$query4 = $this->db->query("select * from bank_details");
    	$data['banks']=$query4->result_array();
        
        $query5 = $this->db->query("SELECT * FROM fees_yearly_contract where activity_id='".$data['activity_id']."'");
    	$data['contract_fee']=$query5->row()->fees_amount;
    	
    	$query6 = $this->db->query("SELECT * FROM vat_setups where id=1");
    	$data['vat_perc']=$query6->row()->percentage;
    	
    	$data['vat_val']=  sprintf("%.2f",($data['contract_fee'] * $data['vat_perc'])/100);
    	$data['total_amount'] = sprintf("%.2f", round($data['contract_fee'] + $data['vat_val'],2));
    	
    	$query7 = $this->db->query("select * from discount_setups");
    	$data['discount_list']=$query7->result_array();
    	
    	$this->load->view('activity_selections_view',$data);
	}
	
	public function updateActivity(){
		
		
	
		$id = $this->input->post('id');
		$from = $this->input->post('from');
		$contract=$this->input->post('contract');
		$level_id=$this->input->post('level_id');
		$head_coach_id=$this->input->post('head_coach_id');
		$status=$this->input->post('status');
		$discount_applicable=$this->input->post('discount_applicable');
		$discount_type=$this->input->post('discount_type');
		$discount_percentage=$this->input->post('discount_percentage');
		$approval_status=$this->input->post('approval_status');
		
		if($discount_applicable == "No")
		{
		    $discount_type = NULL;
		    $discount_percentage = 0.00;
		}

		$email=$this->session->userdata('username');
		$this->db->where('email', $email);  
		$query1 = $this->db->get('users');
		$postData1=$query1->row_array();
		$user_id=$postData1['user_id'];
        $json['from'] = 0;
	    if (empty($json['error']) ) {
		    
        	$updated_at = date('Y-m-d H:i:s');	
        	$sql="Update activity_selections set contract='$contract',level_id='$level_id',head_coach_id='$head_coach_id',status='$status',discount_applicable='$discount_applicable',approval_status='$approval_status',updated_at='$updated_at',discount_type='$discount_type',discount_percentage='$discount_percentage' where id='$id'";
        	$update=$this->db->query($sql);
			if(isset($update)){
				
			
					$email_data_slot = $this->db->query("SELECT a.*,
											   g.level,
											   g.session,
											   gs.game,
											   c.coach_name
										FROM   activity_selections AS a
											   LEFT JOIN game_levels AS g
													  ON a.level_id = g.games_level_id
											   LEFT JOIN games AS gs
													  ON gs.game_id = a.activity_id
											   LEFT JOIN coach AS c
													  ON c.coach_id = a.head_coach_id
										WHERE  a.id = ".$id."");
										
				$email_data_array = $email_data_slot->row_array();	
				if($email_data_array['approval_status']=='Approved')
				{
					$this->send_email($email_data_array);
				}
				
				$json['status'] = "success";
				$json['from'] = $from;
				$this->output->set_header('Content-Type: application/json');
	        	echo json_encode($json);
			}
			$this->session->set_flashdata('success_msg', 'Activity details updated successfully.');
			
	}else{
	    $this->output->set_header('Content-Type: application/json');
	    echo json_encode($json);
	} 
}

	public function send_email($email_data_array)
	{
		
	
		
		$login_url = base_url() .'login';
		//return true;
		//die;
		$this->load->helper('string');
		$this->load->library('phpmailer');
		require_once(APPPATH.'libraries/class.smtp.php');
            
		$mail =  $this->phpmailer;
		//$mail->SMTPDebug = 0;  
		//smtp
		//$mail->isSMTP();
		$mail->SMTPDebug = false;                        
	    $mail->Host = EMAIL_HOST;
		$mail->SMTPAuth = SMTPAUTH;                              
		$mail->Username = SMTP_USERNAME;                 
		$mail->Password = SMTP_PASSWORD;                           
		$mail->SMTPSecure = SMTPSECURE;                    
		$mail->Port = SMTP_PORT;
		$mail->From = FROM_EMAIL;
		$mail->FromName = FROM_NAME;
        $mail->AddCC(CC_ADDRESS);
		$mail->addAttachment(TERMS_CONDITION_ATTACHMENT);
		$mail->addAddress($email_data_array['parent_email_id']);
		$mail->isHTML(true);

		$mail->Subject = "Prime Star Sports Services - Activity approved";
		
		
		$from_html = "";
		$from_html .= "<!DOCTYPE>
<html>
<head>
    <title></title>
    <style>
        table, th, td{ border: 1px solid black;
  border-collapse: collapse;
  height: 41px;
    width: -webkit-fill-available;
        }
        th{
            background-color: #f5efef;
            text-align: left;
        }
    </style>
</head>

<body>
    <div class='logo' style='float: left;
    width: 100%;
    text-align: center;
    background: #ba272d;
    height: 100px; 
    margin-bottom: 20px;'>
        <img src='http://sports.primestaruae.com/images/main_logo.jpg' alt='main_logo' style='height: 100px;'></img>
    </div>
    <div class='header' style='float: left;
    width: 100%;
    text-align: center;
    font-size: 21px;'>
        <h2>Welcome to <span style='color:#ba272d'>Prime Star Sports Services</span></h2>
    </div>
    <div class='main' style='font-family: sans-serif;'>
        <p>Dear <b>".$email_data_array['parent_name'].",</b></p>
        <p>we are pleased to inform you that your kid <b> ".$email_data_array['student_name']." </b> activity has been approved now you can book your slots in active kids menu.. Activity datails as follows.</p>
         <table>
            <tr>
                <th>Reg-ID</th>
                <th>Psa-ID</th>
                <th>Name</th>
                <th>Activity</th>
                <th>Level</th>
                <th>Session</th>
                <th>Head coach</th>
            </tr>
            <tr>
                <td>".$email_data_array['sid']."</td>
                <td>".$email_data_array['psa_id']."</td>
                <td>".$email_data_array['student_name']."</td>
                <td>".$email_data_array['game']."</td>
                <td>".$email_data_array['level']."</td>
                <td>".$email_data_array['session']."</td>
                <td>".$email_data_array['coach_name']."</td>
            </tr>
        </table>
        <h4>Thanks & Regards</h4>
        <h4 style='color: grey'>PSSS Admin team</h4>
        <hr>
        <p>Click here to visit our website:<a href='http://sports.primestaruae.com/'>www.primestaruae.com</a></p>
    </div>";
		$mail->Body = $from_html;
		$mail->AltBody = "This is the plain text version of the email content";
		
		if(!$mail->send()) 
		{
			return false;
		   //echo "Mailer Error: " . $mail->ErrorInfo;
		}
		else{
			return true;
		}
		
	}
	
public function addContractPayment()
{
    
	$activity_selection_id = $this->input->post('activity_selection_id');
	$year=$this->input->post('contract_year');
	$contract_from_date=$this->input->post('contract_from');
	$contract_to_date=$this->input->post('contract_to');
	$contract_gross_amount=$this->input->post('contract_amount');
	$contract_vat_percentage=$this->input->post('vat_percentage');
	$contract_vat_amount=$this->input->post('vat_amount');
	$contract_net_amount=$this->input->post('tot_amount');
	$created_at = date('Y-m-d H:i:s');
	$created_by = $this->session->userdata('userid');
	
    $date1 = str_replace('/', '-', $contract_from_date);
    $contract_from_date = date('Y-m-d', strtotime($date1));
    
    $date2 = str_replace('/', '-', $contract_to_date);
    $contract_to_date = date('Y-m-d', strtotime($date2));
    
    
        	
	$insert_arr = array(
	    'activity_selection_id' => $activity_selection_id,
	    'year' => $year,
	    'contract_from_date' => $contract_from_date,
	    'contract_to_date' => $contract_to_date,
	    'contract_gross_amount' => $contract_gross_amount,
	    'contract_vat_percentage' => $contract_vat_percentage,
	    'contract_vat_amount' => $contract_vat_amount,
	    'contract_net_amount' => $contract_net_amount,
	    'created_at' => $created_at,
	    'created_by' => $created_by
	    );
    $this->db->insert('contract_details' , $insert_arr);
	$insert_id = $this->db->insert_id();
	
	$insert_contract_payments = array();
	$payment_type_arr = $this->input->post('payment_type');
	$payable_date_arr = $this->input->post('payable_date');
	$cheque_date_arr = $this->input->post('cheque_date');
	$payable_amount_arr = $this->input->post('payable_amount');
	$bank_id_arr = $this->input->post('bank_id');
	$cheque_bank_arr = $this->input->post('cheque_bank');
	$cheque_number_arr = $this->input->post('cheque_no');
	
	
	
	foreach($payment_type_arr as $key => $payment)
	{
	    if($payment !='')
	    {
	        $payable_date = $payable_date_arr[$key];
	        $payable_amount = $payable_amount_arr[$key];
	        $bank_id = $bank_id_arr[$key];
	        $date3 = str_replace('/', '-', $payable_date);
            $payable_date = date('Y-m-d', strtotime($date3));
            
            
            $payable_amount = sprintf("%.2f", round($payable_amount,2));
            
	        if($payment == 'Cash')
	        {
	            $insert_arr2 = array(
            	    'contract_detail_id' => $insert_id,
            	    'payment_type' => $payment,
            	    'bank_id' => NULL,
            	    'cheque_bank' => NULL,
            	    'cheque_number' => NULL,
            	    'cheque_date' => NULL,
            	    'payable_date' => $payable_date,
            	    'payable_amount' => $payable_amount,
            	    'created_on' => $created_at,
            	    'created_by' => $created_by
        	    );
	        }
	        else if($payment == 'Card')
	        {
	             $insert_arr2 = array(
            	    'contract_detail_id' => $insert_id,
            	    'payment_type' => $payment,
            	    'bank_id' => $bank_id,
            	    'cheque_bank' => NULL,
            	    'cheque_number' => NULL,
            	    'cheque_date' => NULL,
            	    'payable_date' => $payable_date,
            	    'payable_amount' => $payable_amount,
            	    'created_on' => $created_at,
            	    'created_by' => $created_by
        	    );
	        }
	        else if($payment == 'Online')
	        {
	            $insert_arr2 = array(
            	    'contract_detail_id' => $insert_id,
            	    'payment_type' => $payment,
            	    'bank_id' => $bank_id,
            	    'cheque_bank' => NULL,
            	    'cheque_number' => NULL,
            	    'cheque_date' => NULL,
            	    'payable_date' => $payable_date,
            	    'payable_amount' => $payable_amount,
            	    'created_on' => $created_at,
            	    'created_by' => $created_by
        	    );
        	    
	            
	        }
	        else if($payment == 'Cheque')
	        {
	            
	            $cheque_date = $cheque_date_arr[$key];
    	        $date4 = str_replace('/', '-', $cheque_date);
                $cheque_date = date('Y-m-d', strtotime($date4));
                
                $cheque_bank = $cheque_bank_arr[$key];
                $cheque_number = $cheque_number_arr[$key];
                 
	            $insert_arr2 = array(
            	    'contract_detail_id' => $insert_id,
            	    'payment_type' => $payment,
            	    'bank_id' => NULL,
            	    'cheque_bank' => $cheque_bank,
            	    'cheque_number' => $cheque_number,
            	    'cheque_date' => $cheque_date,
            	    'payable_date' => $payable_date,
            	    'payable_amount' => $payable_amount,
            	    'created_on' => $created_at,
            	    'created_by' => $created_by
        	    );
	        }
    	    
    	    array_push($insert_contract_payments, $insert_arr2);
	    }
    }
    $this->db->insert_batch('contract_payments' , $insert_contract_payments);
    	
	
    echo true;
}
	
}

?>