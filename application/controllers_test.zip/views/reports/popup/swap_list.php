<style type="text/css">
    .modal-lg{max-width: 70% !important;}
</style>
<div class="modal fade rotate" id="swap_details" style="display:none;">
    <div class="modal-dialog modal-lg"> 
            <div class="modal-content panel panel-danger">
                <div class="modal-header panel-heading">
                    <h4 class="modal-title -remove-title">Swap slot Details</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body panel-body" id = "swapTable">
                    
                </div>
                
            </div>
    </div>
</div>
