<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Account_Codes_Model extends CI_Model {


	function __construct()
	{
		parent::__construct();
	}
}
